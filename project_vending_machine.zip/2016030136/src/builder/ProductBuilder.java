package builder;

import consumambles.Consumable;
import exceptions.RecipeStepException;
import userModules.ProductCase;import vendingMachine.Consumer;

public abstract class ProductBuilder {
	
	protected String name;
	protected String type;
	protected int cost;
	protected Product product;

	
	public ProductBuilder() {
		super();
		this.product = new Product();
	}

	public abstract Product getProduct() throws RecipeStepException;


	public void setName(String name) {
		this.name = name;
	}

	public void setCost(int cost) {
		this.cost = cost;
	}

	public abstract void addConsumable( Consumable con) throws RecipeStepException;
	
}

