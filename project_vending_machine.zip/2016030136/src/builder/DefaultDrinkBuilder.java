package builder;

import consumambles.Consumable;
import consumambles.Cup;
import consumambles.Material;
import exceptions.RecipeStepException;

public class DefaultDrinkBuilder extends ProductBuilder {

	
	public DefaultDrinkBuilder() {
		super();
	}



	@Override
	public void addConsumable(Consumable con) throws RecipeStepException {
		
		if(product.consumables.isEmpty() && !(con instanceof Cup)) {
			throw  new RecipeStepException("Something went wrong. No cup loaded.");
			
		}else if (product.consumables.size()>1 && (con instanceof Material)) 
			throw  new RecipeStepException("No more cups needed");
		
		else {
			this.product.consumables.add(con);
			System.out.println("Consumable added.");
			
		}

	}

	@Override
	public Product getProduct() throws RecipeStepException {
//		if (product.consumables.size()<=1)
//			throw  new RecipeStepException("No product was made.");
//		else
			return product;
	}

}
