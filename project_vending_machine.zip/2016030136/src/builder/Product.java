package builder;

import java.util.ArrayList;

import consumambles.Consumable;

public class Product {
	
	public ArrayList<Consumable> consumables;

	public Product() {
		super();
		this.consumables = new ArrayList<Consumable>();
	}

	public ArrayList<Consumable> getConsumables() {
		return consumables;
	}

	public void setConsumables(ArrayList<Consumable> consumables) {
		this.consumables = consumables;
	}
	
}
