package processors;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import consumambles.Consumable;
import consumambles.Ingredient;
import consumambles.ProcessedIngredient;
import containers.FlowContainer;
import exceptions.CloseModuleException;
import exceptions.LockedModuleException;
import exceptions.NotExistantConsumable;
import exceptions.PluggedException;
import hw.consoles.ProcessorConsole;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;
import userModules.ProductCase;
import vendingMachine.Consumer;

public class IngredientProcessor extends FlowContainer<ProcessorDevice> implements Processor {   //vgazw tis klaseis boiler, cooler klp kai tis antikathistw me aythn
	

	
	private ArrayList<Class> acceptCons;   
	private ProcessedIngredient processedIng;
	protected String processorName;
	protected Class<? extends Consumable>  acceptedCons;

	public IngredientProcessor( ProcessorDevice dev) {
		super(dev);
		//acceptCons = new ArrayList<>();
	//	this.acceptCons = (IngredientProcessor)dev.
		this.processedIng = new ProcessedIngredient(((ProcessorDevice) this.device).getProcessingLabel(), dev.getCapacity());


	}
	//		acceptcons lista me ingre mesa ston constructor pou elegxw stin accept an einai mesa 


	public String getProcessorName() {
		return processorName;
	}
	
	@Override
	public void load(Consumable con) {			
		
		System.out.println("Loading...");
		
		if(con!=null) {
			this.setContent(con);
			this.setContCapacity(con.getQuantity());
			this.processedIng.ingre.put(con.getName(), (Ingredient) con);
		}
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public boolean accepts(Consumable consumable) { 		
		
		if (consumable instanceof Ingredient) {
			System.out.println("Accepted");
			return true;
		}else return false;
	}
		

	@Override
	public void process(int duration) {        
			
		this.device.open();
		if(!this.device.isOpen()){
			try {
				throw new CloseModuleException("Closed");
			} catch (CloseModuleException e) {
				e.printStackTrace();
			}
		}
		
		((ProcessorDevice)this.device).operateStart();
		
		try {
			TimeUnit.SECONDS.sleep(duration);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		System.out.println("Processing for "+ duration + " sec.");
		System.out.println(this.processedIng.getName());
		((ProcessorDevice)this.device).operateStop();
		this.device.close();


	}
	
	public void provide(Consumer conRef) {
		if(conRef.getClass().equals(ProductCase.class)) {
			try {
				conRef.load(this.processedIng);
			} catch (NotExistantConsumable e) {
				e.printStackTrace();
			}
		} else {
			try {
				if(isPlugged()==false) {
					try {
						plug(conRef);
					} catch (PluggedException e) {
		        		System.out.println("Couldn't be plugged");
						e.printStackTrace();
					}
					conRef.load(processedIng);
				}
			} catch (NotExistantConsumable e) {
						// TODO Auto-generated catch block
					e.printStackTrace();
			}
			System.out.println("Content loaded");

			try {
				unPlug(conRef);
			} catch (PluggedException e) {
        		System.out.println("Couldn't be unplugged");
				e.printStackTrace();
			}
			
		}
			
	}
		
}
	
	
