package processors;

import vendingMachine.Consumer;
import vendingMachine.Pluggable;

public interface Processor extends Consumer, Pluggable{

		public void process(int duration);
		
}
