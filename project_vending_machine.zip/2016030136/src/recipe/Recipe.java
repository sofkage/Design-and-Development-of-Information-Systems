package recipe;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import consumambles.Ingredient;
import consumambles.Liquid;
import consumambles.Powder;
import exceptions.MalformedRecipeException;

public class Recipe {
    private String name;
    private int code;
    private int cost;    
    private boolean active;
    private String type;
    public LinkedList<RecipeStep> steps;
    private LinkedList<Ingredient> ingredients = new LinkedList<Ingredient>();
    
    public Recipe() {
        this.active=true;
        this.steps = new LinkedList<>();     
        type = "DefaultDrink";
        
    }


	public String getName() {
        return name;
    }

    public int getCost() {
        return cost;
    }

    public String getType() {
        return type;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setCost(int cost) {
        this.cost = cost;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }



    public Recipe(String name) {
        this();
        this.name = name;
    }

    public Recipe(String name, int code) {
        this(name);
        this.code = code;
    }

    public Recipe(int code){
        this();
        this.code=code;
    }

    public Recipe(String name, int code, int cost) {
        this(name,code);
        this.cost = cost;

    }

    public Recipe(String name, int code, int cost, String type) {
        this(name, code, cost);
        this.type = type;
    }

    public void addStep(RecipeStep step) {
        this.steps.add(step);
    }

    public boolean isEnabled() {
        return active;
    }

    public void enable() {
        this.active = true;
    }

    public void disable(){
        this.active=false;
    }

    public boolean hasMoreSteps() {
        return false;
    }

    public RecipeStep getNextStep() {      
            return null;      
    }
    
    public void addIngredient(Ingredient i) {
        this.ingredients.add(i);
    }

    public List<Ingredient> getIngredients(){
        return this.ingredients;
    }

//    ?????????
    public void unMarshal(String recipeTxt) throws MalformedRecipeException {
    	System.out.println("\nUnmarshaling Recipe from text: ");
    	System.out.println("|----------------------------------------------------------|");
    	System.out.println(recipeTxt);
    	System.out.println("|----------------------------------------------------------|");
    	
    	
    	String costtostr=null,ing,n;
    	//String tmp;
        
    	   while (recipeTxt.indexOf("\n")!=-1) {
    		   

    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf(":"));
    	    	this.name=recipeTxt.substring(0,recipeTxt.indexOf("\n"));
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf(":")+1);
    	    	System.out.println("Name: "+this.name);

    	    	this.type=recipeTxt.substring(0,recipeTxt.indexOf("\n"));
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf(":")+2);
    	    	costtostr=recipeTxt.substring(0,recipeTxt.indexOf("\n"));
    	    	System.out.println("Type: "+this.type);

    	    	this.cost = Integer.parseInt(costtostr);
    	    	System.out.println("Cost: "+this.cost);
    	    	
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	    	ing=recipeTxt.substring(0,recipeTxt.indexOf("\n"));
    	    	
    	    	String ingre = recipeTxt.substring(0,12);  //INGREDIENTS:
    	    	System.out.println(ingre);
    	    	
//    	    	ingre = ingre.substring(11);
    	    	ing=recipeTxt.substring(13,recipeTxt.indexOf("\n"));
    	    	
    	    	String ings[] = ing.split(",");
    			for(int i =0; i <ings.length; i++) {
    				
					String in[]= ings[i].split(":");
    				
    				
    				if(in[0].equals("PWD")) {
    					
    					ingredients.add(new Powder(in[1], Integer.parseInt(in[2])));
    					System.out.println((i+1) +") " +ingredients.get(i).getName());
    				} else {
    					ingredients.add(new Liquid(in[1], Integer.parseInt(in[2])));
    					System.out.println((i+1) +") " +ingredients.get(i).getName());

    				}
    			}
    	    	
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf(":")+1);
    	    	n=recipeTxt.substring(0,recipeTxt.indexOf("\n"));
    	    	recipeTxt=recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	            	
    	    	
    	    	String tmp,qstr;
    	    	String from,to,what,processor;
    	    	int quantity,duration;
    	    	while(recipeTxt.indexOf("\n")!=-1) {
    	    		
    	        	tmp=recipeTxt.substring(0,recipeTxt.indexOf(" ")+1);
    	        	
    	        	  if(tmp.equals("TRANSFER ")) {
    	        		   tmp=recipeTxt.substring(recipeTxt.indexOf(" "),recipeTxt.indexOf("\n"));
    	        		   
    	        		   tmp=tmp.substring(tmp.indexOf(" ")+1);
    	        		   tmp=tmp.substring(0,tmp.indexOf(" "));
    	        		   from=tmp.substring(tmp.indexOf(" ")+1);
    	        		   System.out.println("from "+from);
    	        		  
    	        		   tmp=recipeTxt.substring(recipeTxt.indexOf(" ")+1,recipeTxt.indexOf("\n"));
    	        		  
    	        		   tmp=tmp.substring(tmp.indexOf(" ")+1);
    	        		   tmp=tmp.substring(0,tmp.indexOf(" "));
    	        		   to=tmp.substring(tmp.indexOf(" ")+1);
    	         		   System.out.println("to "+to);  		   
    	       		       
    	         		   tmp=recipeTxt.substring(recipeTxt.indexOf(" ")+14,recipeTxt.indexOf("\n"));
    	         	
    	         		   tmp=tmp.substring(tmp.indexOf(" ")+1);
    	     		       tmp=tmp.substring(0,tmp.indexOf(" "));
    	   		           what=tmp.substring(tmp.indexOf(" ")+1); 
    	   		           System.out.println("what "+what);
    	   		          
    	   		           tmp=recipeTxt.substring(recipeTxt.indexOf(" ")+22,recipeTxt.indexOf("\n"));
    	   		           quantity = Integer.parseInt(tmp);
    	                   System.out.println("quantity "+quantity);
    	                   TransferStep ts = new TransferStep(from, to, what, quantity);
    	                   
    	        			steps.add(ts);
    	        			
    	        			
    	    	}if (tmp.equals("OPERATE ")) {
    	    		
    	    	 	tmp=recipeTxt.substring(recipeTxt.indexOf(" ")+1,recipeTxt.indexOf("\n"));
    	    		
    	    	      
    			      tmp=tmp.substring(0,tmp.indexOf(" "));
    			      processor=tmp.substring(tmp.indexOf(" ")+1); 
    	    		  System.out.println("processor "+processor);
    	    		 
    	    		  tmp=recipeTxt.substring(recipeTxt.indexOf(" ")+1,recipeTxt.indexOf("\n"));
    	    		  
    	    		   tmp=tmp.substring(tmp.indexOf(" ")+1);  
    	  		     	  		 
    	              duration = Integer.parseInt(tmp);
    	    		  System.out.println("duration "+duration + " sec");
    	              OperateStep os= new OperateStep(processor,duration);
    	              steps.add(os);
    	    	}
    	    	recipeTxt = recipeTxt.substring(recipeTxt.indexOf("\n")+1);
    	      }
    	    }
    	    
    	
    	   
    }
    
    
    public String marshal() {
        StringBuilder sb=new StringBuilder("");
        sb.append("NAME: ").append(this.name).append("\n");
        sb.append("TYPE: ").append(this.type).append("\n");
        sb.append("PRICE: ").append(this.cost).append("\n");
        sb.append("INGREDIENTS: ");
        for (Ingredient i : this.ingredients){
            if (i instanceof Liquid){
                sb.append("LIQ:");
            }else{
                sb.append("PWD:");
            }
            sb.append(i.getName()).append(":").append(i.getQuantity()).append(",");
        }
        sb.delete(sb.lastIndexOf(","),sb.length());
        sb.append("!");
        return sb.toString();
    }
    

    public void print(){
        System.out.println(this.type + ": "+ this.name + ", Price: " + this.cost);
        for (RecipeStep step : steps) {
            step.print();
        }
    }

}