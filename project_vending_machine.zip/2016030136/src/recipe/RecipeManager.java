package recipe;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import consumambles.Ingredient;
import consumambles.Liquid;
import consumambles.Powder;
import containers.Container;
import containers.DosingContainer;
import containers.FlowContainer;
import containers.MaterialContainer;
import dispensers.Dispenser;
import processors.IngredientProcessor;
import recipe.dao.DAOFactory;
import recipe.dao.RecipeDAO;
import tuc.ece.cs201.vm.hw.impl.gui.GraphicContainer;
import tuc.ece.cs201.vm.hw.impl.gui.SwingVM;
import userModules.DisplayPanel;
import userModules.Module;
import vendingMachine.Consumer;
import vendingMachine.VendingMachine;

public class RecipeManager {    
    DAOFactory daoFactory;
    RecipeDAO recipeDAO;         //DAO
    private int numOfEnabled;
    private boolean loaded;
    private HashMap<Integer,Recipe> recipes;

    public RecipeManager() throws IllegalAccessException {
        daoFactory = DAOFactory.getDAOFactory("FS");
        this.recipes = new HashMap<>();
        this.numOfEnabled =0;
        this.loaded=false;
    }

    public void loadRecipes(){
        recipeDAO = daoFactory.getRecipeDAO();
        for (Recipe r : recipeDAO.loadRecipes()){
            this.recipes.put(r.getCode(),r);
        }
        this.loaded=true;        
    }

    public int getNumOfEnabled() {
        return numOfEnabled;
    }

    public Recipe getRecipe(Integer code){
        return recipes.get(code);
    }

    public List<Recipe> getRecipes(){
        if (!loaded){
            this.loadRecipes();
        }
        return new ArrayList<>(this.recipes.values());
    }
    
    public boolean canBeExecuted(Recipe recipe, VendingMachine vm) {
    	
    		for( Ingredient ingre : recipe.getIngredients()) {
    			if(ingre.getQuantity() > ((Container)vm.modules.get(ingre.getName().substring(0,1)+ingre.getName().substring(1).toLowerCase())).getContent().getQuantity()) {
    				return false;
    			}
    		}
    		return true;
    }
    
    public boolean canBeExecuted(Recipe recipe, SwingVM svm) {
    	
 		for( Ingredient ingre : recipe.getIngredients()) {
 			GraphicContainer cont = (GraphicContainer)svm.devices.get(ingre.getName());
			if(ingre.getQuantity() > cont.getCurrentQuantity()) {
				return false;
			}
		}
 		return true;
    }

    
    public void executeRecipe(Recipe recipe, VendingMachine vm, DisplayPanel dp) {
    	Module m;
    	Boolean canBeExecuted = canBeExecuted(recipe, vm);
    	Container<?> conFrom;
    	
    	
		    	for(int i = 0; i< recipe.steps.size(); i++) {
					if(recipe.steps.get(i).getClass().equals(OperateStep.class)) {
						OperateStep operateStep = (OperateStep)recipe.steps.get(i);
						
						String processorName = operateStep.getProcessor().substring(0,1).toUpperCase() + operateStep.getProcessor().substring(1).toLowerCase();
						m =  vm.modules.get(processorName);
						
		//						if(operateStep.getProcessor().equals("BOILER")) 
		//							m = vm.modules.get("Boiler");
						
						IngredientProcessor ingredientProcessor = (IngredientProcessor)m;
						ingredientProcessor.process(operateStep.getDuration());
						
					}else if(recipe.steps.get(i).getClass().equals(TransferStep.class)) {
						TransferStep transferStep = (TransferStep)recipe.steps.get(i);
						
						Consumer conTo = null;
						conFrom = null;
						
						String processorNameFrom = transferStep.getFrom().substring(0,1).toUpperCase() + transferStep.getFrom().substring(1).toLowerCase();
						m =  vm.modules.get(processorNameFrom);
						conFrom = (IngredientProcessor)m;   //boiler klp
						
						if(transferStep.getFrom().equals("POWDERS")) {
							
							String dosingContNameWhat = transferStep.getWhat().substring(0,1).toUpperCase() + transferStep.getWhat().substring(1).toLowerCase();
							m =  vm.modules.get(dosingContNameWhat);
							conFrom = (DosingContainer)m;
							
							
		//							if(transferStep.getWhat().equals("SUGAR")) 
		//								conFrom = (DosingContainer) vm.modules.get("Sugar");			
						}
						
						if(transferStep.getFrom().equals("LIQUIDS")) {
							
							String flowContNameWhat = transferStep.getWhat().substring(0,1).toUpperCase() + transferStep.getWhat().substring(1).toLowerCase();
							m =  vm.modules.get(flowContNameWhat);
							conFrom = (FlowContainer)m;
							
		//							if(transferStep.getWhat().equals("MILK")) 
		//								conFrom = (FlowContainer) vm.modules.get("Milk");
							
						}
					
						if(transferStep.getFrom().equals("CUPS")) {
							
							String materialContNameWhat = transferStep.getWhat().substring(0,1).toUpperCase() + transferStep.getWhat().substring(1).toLowerCase();
							m =  vm.modules.get(materialContNameWhat);
							conFrom = (MaterialContainer)m;
							
		//							if(transferStep.getWhat().equals("BIGCUP")) 
		//								conFrom = (MaterialContainer) vm.modules.get("Big Cup");
		//							
						}

						
						String processorNameTo =transferStep.getTo().substring(0,1).toUpperCase() +transferStep.getTo().substring(1).toLowerCase();
						m =  vm.modules.get(processorNameTo);
						
						if(processorNameTo.equals("Cup_case"))
							m = vm.modules.get("Product Case");
		
						conTo = (Consumer)m;
		
						if(transferStep.getWhat().equals("ALL")) 
							conFrom.provide(conTo);	
						else
							conFrom.provide(conTo, transferStep.getQuantity());
						
				
						dp.displayMsg("Transfer "+conFrom.getName() + " to " + transferStep.getTo() );
				
				
					}
				}
    }
}
    


