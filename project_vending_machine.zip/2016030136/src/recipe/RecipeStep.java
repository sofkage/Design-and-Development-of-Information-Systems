package recipe;

public abstract class RecipeStep {

    public abstract void print();

}
