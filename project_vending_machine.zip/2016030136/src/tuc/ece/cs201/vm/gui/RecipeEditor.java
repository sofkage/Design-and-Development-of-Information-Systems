package tuc.ece.cs201.vm.gui;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.event.WindowListener;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

import recipe.Recipe;

public class RecipeEditor extends JFrame {
	private RecipeBuilder rbuilder;
	private RecipeViewer rviewer;
	
	public RecipeEditor() {
		super("Recipe Editor");
		setVisible(true);
		
		rbuilder = new RecipeBuilder();
		rviewer = new RecipeViewer();
		
		Container contPane = this.getContentPane();
	    contPane.add(rbuilder,BorderLayout.LINE_START);
	    contPane.add(rviewer,BorderLayout.LINE_END);
	    pack();
	}

	public void addWindowObserver(WindowListener listener) {
		this.addWindowListener(listener);
	}
	
	
	public RecipeBuilder getRbuilder() {
		return rbuilder;
	}

	public RecipeViewer getRviewer() {
		return rviewer;
	}
	
	public void showDialogMessage(String message) {
		JOptionPane.showMessageDialog(this, message);
	}
	
//	
//	public static void main(String[] args) {
//		Recipe model = new Recipe();
//		RecipeEditor view =  ;
//		AppController ac = new AppController(view,model);
//	}

}
