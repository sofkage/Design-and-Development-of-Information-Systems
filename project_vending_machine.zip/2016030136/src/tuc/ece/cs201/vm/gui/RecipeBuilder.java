package tuc.ece.cs201.vm.gui;

import java.awt.GridLayout;
import java.awt.event.ActionListener;
import java.awt.event.ItemListener;
import java.util.List;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import consumambles.Ingredient;

public class RecipeBuilder extends JPanel
{
	public static String[] ings_powder = {"COFFEE","SUGAR","COCOA"};
	public static String[] ings_liquid = {"WATER","MILK","SIRUP"};
	public static String[] ing_types = {"POWDERS","LIQUIDS"};
	
	JPanel p1, p2;
	JComboBox ingredients,ingredient_types;
	JTextField name, code, cost;
	JTextField qField;
	JButton aButton,sButton;
	JList ilist;

	
	public RecipeBuilder() {
		setBorder(new EmptyBorder(10, 10, 10, 10));
		name = new JTextField(10);
		code = new JTextField(3);
		cost = new JTextField(5);
		
		ingredients= new JComboBox(ings_powder);
		ingredient_types= new JComboBox(ing_types);
		qField = new JTextField(3);
		aButton = new JButton("Add");
		ilist  = new JList();

		sButton = new JButton("Show Recipe");
		sButton.setActionCommand("Show");
		
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		
		p1 = new JPanel();
		p1.setLayout(new GridLayout(0,2));
		p1.add(new JLabel("Name"));
		p1.add(name);
		p1.add(new JLabel("Code"));
		p1.add(code);
		p1.add(new JLabel("Cost"));
		p1.add(cost);
		this.add(p1);
		p2 = new JPanel();
		p2.add(ingredient_types);
		p2.add(ingredients);
		p2.add(qField);
		p2.add(aButton);
		this.add(p2);
		
		JLabel ling = new JLabel("Ingredients");
		ling.setAlignmentX(CENTER_ALIGNMENT);
		this.add(ling);
		
		JScrollPane jp = new JScrollPane();
		jp.setViewportView(ilist);
		jp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		this.add(jp);
		
		sButton.setAlignmentX(CENTER_ALIGNMENT);
		this.add(sButton);
	}

	public String getSelectedIngredientType() {
		return (String)ingredient_types.getSelectedItem();
	}
	
	public String getIngredient() {
		return (String)ingredients.getSelectedItem();
	}
	
	public void resetQuantity() {
		qField.setText("");
	}
	
	public int getQuantity() {
		return Integer.parseInt(qField.getText());
	}
	
	public void showIngredients(List<Ingredient> ing) {
		ilist.setListData(ing.toArray());
		ilist.ensureIndexIsVisible(ing.size()-1);
	}
	
	public void loadTypeIngredients() {
		if (((String)ingredient_types.getSelectedItem()).equals("POWDERS"))
			ingredients.setModel(new DefaultComboBoxModel<String>(ings_powder));
		else 
			ingredients.setModel(new DefaultComboBoxModel<String>(ings_liquid));
	}	
	
	public String getRecipeName() {
		return name.getText();
	}
	
	public int getRecipeCode() {
		return Integer.parseInt(code.getText());
	}
	
	public int getRecipeCost() {
		return Integer.parseInt(cost.getText());
	}
	
	public void addButtonObserver(ActionListener listener) {
		aButton.addActionListener(listener);
		sButton.addActionListener(listener);
	}
	public void addComboObserver(ItemListener listener) {
		ingredient_types.addItemListener(listener);
	}
	
}
