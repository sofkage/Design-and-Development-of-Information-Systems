package tuc.ece.cs201.vm.gui;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.border.EmptyBorder;

public class RecipeViewer extends JPanel {
	JLabel rep_label;
	JTextArea recipe_text;
	JButton save_file;

	public RecipeViewer() {
		setBorder(new EmptyBorder(10, 10, 10, 10));
		rep_label = new JLabel("Recipe Text");
		rep_label.setAlignmentX(LEFT_ALIGNMENT);
		recipe_text = new JTextArea();
		recipe_text.setLineWrap(true);
		Dimension d = new Dimension(400, 150);
		recipe_text.setPreferredSize(d);
		recipe_text.setBackground(Color.white);
		save_file = new JButton("Save Recipe");
		save_file.setActionCommand("Save");
		save_file.setAlignmentX(LEFT_ALIGNMENT);
		save_file.setEnabled(false);
		recipe_text.setAlignmentX(LEFT_ALIGNMENT);

		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(rep_label);
		this.add(Box.createRigidArea(new Dimension(0, 10)));
		this.add(recipe_text);
		this.add(Box.createRigidArea(new Dimension(0, 10)));
		this.add(save_file);
	}

	public void addButtonObserver(ActionListener listener) {
		save_file.addActionListener(listener);
	}

	public void setRecipeText(String text) {
		recipe_text.setText(text);
		save_file.setEnabled(true);
	}

}
