package tuc.ece.cs201.vm.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import consumambles.Ingredient;
import consumambles.Liquid;
import consumambles.Powder;
import recipe.Recipe;
import recipe.dao.DAOFactory;
import recipe.dao.RecipeDAO;

public class AppController extends WindowAdapter implements ActionListener, ItemListener{
	
	Recipe recipe_model;
	RecipeEditor recipe_view;
	
	DAOFactory daoFactory;
    RecipeDAO recipeDAO;
	
	public AppController(RecipeEditor view, Recipe model) {
		recipe_model = model;
		recipe_view = view;
		recipe_view.getRbuilder().addButtonObserver(this);
		recipe_view.getRbuilder().addComboObserver(this);
		recipe_view.getRviewer().addButtonObserver(this);
		recipe_view.addWindowObserver(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getActionCommand().equals("Add")) {
			Ingredient ing;
			if (recipe_view.getRbuilder().getSelectedIngredientType().equals("LIQUIDS"))
				ing = new Liquid(recipe_view.getRbuilder().getIngredient(), recipe_view.getRbuilder().getQuantity());
			else
				ing = new Powder(recipe_view.getRbuilder().getIngredient(), recipe_view.getRbuilder().getQuantity());
			recipe_model.addIngredient(ing);
			recipe_view.getRbuilder().resetQuantity();
			recipe_view.getRbuilder().showIngredients(recipe_model.getIngredients());
		}
		else if (e.getActionCommand().equals("Show")) {
			recipe_model.setName(recipe_view.getRbuilder().getRecipeName());
			recipe_model.setCost(recipe_view.getRbuilder().getRecipeCost());
			recipe_model.setCode(recipe_view.getRbuilder().getRecipeCode());
			recipe_view.getRviewer().setRecipeText(recipe_model.marshal());
		} else {
			try {
				daoFactory = DAOFactory.getDAOFactory("FS");
				recipeDAO = daoFactory.getRecipeDAO();
				recipeDAO.storeRecipe(recipe_model);
				recipe_view.showDialogMessage("Recipe saved!");
			} catch (Exception ex) {
				recipe_view.showDialogMessage("Recipe could not be saved!");
			}
			
		}
	}

	@Override
	public void itemStateChanged(ItemEvent arg0) {
		recipe_view.getRbuilder().loadTypeIngredients();
	}
	
	@Override
	public void windowClosing(WindowEvent event) {
		      System.out.println("Exit Window Application");
		      System.exit(0);
	}
}
