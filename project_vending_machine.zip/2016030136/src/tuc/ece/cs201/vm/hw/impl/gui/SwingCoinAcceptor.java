package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import vendingMachine.Coins;

public class SwingCoinAcceptor extends JPanel implements ActionListener, CoinAcceptorDevice {

	JTextField enterMoneyTextField;
	JLabel jlabel;
	String name;

	public int inputMoney = 0;

	boolean active;

	public SwingCoinAcceptor() {
		jlabel = new JLabel("Coin Acceptor");
		jlabel.setAlignmentX(LEFT_ALIGNMENT);
		enterMoneyTextField = new JTextField();
		enterMoneyTextField.setAlignmentX(LEFT_ALIGNMENT);
		enterMoneyTextField.setToolTipText("Enter Coin Here...");
		enterMoneyTextField.addActionListener(this);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(jlabel);
		this.add(enterMoneyTextField);
		this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		enterMoneyTextField.setEnabled(active);
		this.name = "Coin Acceptor";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void reset()
	{
		inputMoney = 0;
	}

	@Override
	public synchronized void actionPerformed(ActionEvent ev) {
		SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");

		try {
			String priceEntered = enterMoneyTextField.getText();

			int coin = Integer.parseInt(priceEntered);

			if (coin != Coins.cents_1 && coin != Coins.cents_2 && coin != Coins.cents_5 && coin != Coins.cents_10
					&& coin != Coins.cents_20 && coin != Coins.cents_50 && coin != Coins.cents_100
					&& coin != Coins.cents_200) {
				displayPanel.displayMsg("Machine accepts only: 1, 2, 5, 10, 20, 50, 100, 200 cents");
			} else {
				displayPanel.displayMsg("You Have Entered " + (double) acceptCoin(coin) / 100 + " � in total");
			}
		} catch (Exception ex) {
			displayPanel.displayMsg("Please enter the correct coin amount in cents (only numbers)");
		}
	}

	@Override
	public boolean isLocked() {
		return active;
	}

	@Override
	public void lock() {
		this.setBackground(SwingVM.deactive_color);
		enterMoneyTextField.setEnabled(false);
		active = false;
	}

	@Override
	public void unLock() {
		this.setBackground(SwingVM.active_color);
		enterMoneyTextField.setEnabled(true);
		active = true;
	}

	@Override
	public void connect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnectAll() {
		// TODO Write code...

	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Write code...
		return null;
	}

	@Override
	public int acceptCoin(int coin) {
		try {
			inputMoney += coin;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return inputMoney;
	}
}
