package tuc.ece.cs201.vm.hw.impl.gui;

import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import recipe.Recipe;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;

public class SwingDisplayPanel extends JPanel implements DisplayDevice {
	private static final long serialVersionUID = 1L;

	JTextArea menuLabel;
	JLabel jlabel;
	JTextArea infoLabel;
	String name;
	boolean active;

	public SwingDisplayPanel() {
		jlabel = new JLabel("Display Panel");
		jlabel.setAlignmentX(LEFT_ALIGNMENT);
		menuLabel = new JTextArea("");
		menuLabel.setAlignmentX(LEFT_ALIGNMENT);
		menuLabel.setLineWrap(true);
		menuLabel.setWrapStyleWord(true);
		menuLabel.setEditable(false);
		infoLabel = new JTextArea("");
		infoLabel.setAlignmentX(LEFT_ALIGNMENT);
		infoLabel.setLineWrap(true);
		infoLabel.setWrapStyleWord(true);
		infoLabel.setEditable(false);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(jlabel);
		this.add(menuLabel);
		this.add(infoLabel);
		this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		this.name = "Display Panel";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void connect(Device arg0) {
	}

	@Override
	public void disconnect(Device arg0) {
	}

	@Override
	public void disconnectAll() {
	}

	@Override
	public List<Device> listConnectedDevices() {
		return null;
	}

	@Override
	public void clear() {
		infoLabel.setText("");
	}

	@Override
	public void displayMsg(String message) {
		infoLabel.setText(message);
	}

	public void displayMenu(List<Recipe> recipes) {
		if (recipes.isEmpty())
			menuLabel.setText("Recipe list Empty!");
		
		StringBuilder products = new StringBuilder();
		for (int i = 0; i < recipes.size(); i++) {
			
			products.append((i+1)+")"+recipes.get(i).getCode() + " " + recipes.get(i).getName() + ", " + recipes.get(i).getCost() + " cents\n");
		}
		
		menuLabel.setText(products.toString());
	}
}
