package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.Color;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;

public class GraphicDosingContainer extends GraphicContainer implements DosingContainerDevice{
	int doseSize = 5;

	public GraphicDosingContainer(String name, int capacity, int dose_size, int x, int y, int width, int height, int border, Color color) {
		super(name, capacity, x, y, width, height, border, color);
		doseSize = dose_size;
	}

	@Override
	public int doseSize() {
		// TODO Auto-generated method stub
		return doseSize;
	}

	@Override
	public void releaseDose(Device toConnectedDevice) {
		decreaseContent(doseSize);
		//load content to connected device
	}

}
