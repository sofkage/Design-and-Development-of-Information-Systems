package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;

public class SwingNumPad extends JPanel implements ActionListener, NumPadDevice {

	ButtonArray jnumpad;
	JLabel jlabel;
	String name;
	//String name set kai get

	boolean active;

	String code = "";

	public SwingNumPad() {
		jlabel = new JLabel("Numpad");
		jlabel.setAlignmentX(LEFT_ALIGNMENT);
		jnumpad = new ButtonArray(this);
		jnumpad.setAlignmentX(LEFT_ALIGNMENT);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(jlabel);
		this.add(jnumpad);
		this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		jnumpad.setEnabled(active);
		this.name = "Num Pad";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void reset()  //code=0
	{
		code = "";
	}

	@Override
	public synchronized void actionPerformed(ActionEvent ev) {
		try {
			if ("c".equals(ev.getActionCommand())) {
				code = "";
			} else if ("ok".equals(ev.getActionCommand())) {
				if (code.equals("")) {
					SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
					displayPanel.displayMsg("Please type a code from the Menu below and then click ok button.");
				} else {
					notify();
				}
			} else {
				code += ev.getActionCommand();
			}
		} catch (NumberFormatException ex) {
		}
	}

	public synchronized int readDigit(String c) {
		try {
			wait();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		return Integer.parseInt(code);
	}

	class ButtonArray extends JPanel {
		JButton[] b = new JButton[10];

		JButton clear;
		JButton ok;

		public ButtonArray(ActionListener al) {
			GridLayout gl = new GridLayout(0, 3);
			this.setLayout(gl);
			for (int i = 1; i < 10; i++) {
				b[i] = new JButton("" + i);
				this.add(b[i]);
				b[i].addActionListener(al);
			}
			b[0] = new JButton("0");
			this.add(b[0]);
			b[0].addActionListener(al);

			clear = new JButton("c");
			this.add(clear);
			clear.addActionListener(al);

			ok = new JButton("ok");
			this.add(ok);
			ok.addActionListener(al);
		}

		public void setEnabled(boolean st) {
			for (int i = 0; i < this.getComponentCount(); i++) {
				this.getComponent(i).setEnabled(st);
			}
		}

	}

	@Override
	public boolean isLocked() {
		return active;
	}

	@Override
	public void lock() {
		this.setBackground(SwingVM.deactive_color);
		jnumpad.setEnabled(false);
		active = false;
	}

	@Override
	public void unLock() {
		this.setBackground(SwingVM.active_color);
		jnumpad.setEnabled(true);
		active = true;
	}

	@Override
	public void connect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnectAll() {
		// TODO Write code...

	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Write code...
		return null;
	}
}
