package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import builder.Product;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;

public class SwingProductCase extends JPanel implements ActionListener, ProductCaseDevice {
	JLabel jlabel;
	JButton getProductBtn;
	String name;
	
	boolean active;

	Product finalProduct;

	public void setFinalProduct(Product finalProduct) {
		this.finalProduct = finalProduct;
	}

	public SwingProductCase() {
		jlabel = new JLabel("Product Case");
		jlabel.setAlignmentX(LEFT_ALIGNMENT);
		getProductBtn = new JButton("Get Product");
		getProductBtn.addActionListener(this);
		getProductBtn.setAlignmentX(LEFT_ALIGNMENT);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(jlabel);
		this.add(getProductBtn);
		this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		getProductBtn.setEnabled(active);
		this.name = "Product Case";
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public synchronized void actionPerformed(ActionEvent ev) {
		try {
			SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
			displayPanel.displayMsg("You got your product. Enjoy!\n" + getNameProduct());
			lock();
		} catch (Exception ex) {
		}
	}

	public String getNameProduct() {
		if (finalProduct.consumables.size() == 0) {
			return "";
		}

		String name = "Product(";
		for (int i = 0; i < finalProduct.consumables.size(); i++) {
			name = name + finalProduct.consumables.get(i).getName() + ",";
		}
		name = name.substring(0, name.length() - 1);
		return name + ")";

	}

	@Override
	public boolean isLocked() {
		return active;
	}

	@Override
	public void lock() {
		this.setBackground(SwingVM.deactive_color);
		getProductBtn.setEnabled(false);
		active = false;
	}

	@Override
	public void unLock() {
		this.setBackground(SwingVM.active_color);
		getProductBtn.setEnabled(true);
		active = true;
	}

	@Override
	public void connect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnectAll() {
		// TODO Write code...

	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Write code...
		return null;

	}

	@Override
	public void loadIngredient(String ingredientType) {
		SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
		displayPanel.displayMsg(ingredientType + " loaded  ");
	}

	@Override
	public void putMaterial(String materialType) {
		SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
		displayPanel.displayMsg(materialType + " was added to product ");
	}
}
