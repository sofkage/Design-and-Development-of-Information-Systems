package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import vendingMachine.Coins;

public class SwingChangeCase extends JPanel implements ActionListener, ChangeCaseDevice {
	JLabel jlabel;
	JButton removeChangeBtn;
	String name;

	int changeMoney = 0;

	int cent_1_num = 0;
	int cent_2_num = 0;
	int cent_5_num = 0;
	int cent_10_num = 0;
	int cent_20_num = 0;
	int cent_50_num = 0;
	int cent_100_num = 0;
	int cent_200_num = 0;

	boolean active;

	public SwingChangeCase() {
		jlabel = new JLabel("Change Case");
		jlabel.setAlignmentX(LEFT_ALIGNMENT);
		removeChangeBtn = new JButton("Get Change");
		removeChangeBtn.addActionListener(this);
		removeChangeBtn.setAlignmentX(LEFT_ALIGNMENT);
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(jlabel);
		this.add(removeChangeBtn);
		this.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		removeChangeBtn.setEnabled(active);
		this.name = "Change Case";
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void reset()
	{
		changeMoney = 0;

		cent_1_num = 0;
		cent_2_num = 0;
		cent_5_num = 0;
		cent_10_num = 0;
		cent_20_num = 0;
		cent_50_num = 0;
		cent_100_num = 0;
		cent_200_num = 0;
	}

	@Override
	public synchronized void actionPerformed(ActionEvent ev) {
		try {
			removeChange();
		} catch (Exception ex) {
		}
	}

	@Override
	public boolean isLocked() {
		return active;
	}

	@Override
	public void lock() {
		this.setBackground(SwingVM.deactive_color);
		removeChangeBtn.setEnabled(false);
		active = false;
	}

	@Override
	public void unLock() {
		this.setBackground(SwingVM.active_color);
		removeChangeBtn.setEnabled(true);
		active = true;
	}

	@Override
	public void connect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnect(Device arg0) {
		// TODO Write code...

	}

	@Override
	public void disconnectAll() {
		// TODO Write code...

	}

	@Override
	public List<Device> listConnectedDevices() {
		// TODO Write code...
		return null;
	}

	@Override
	public void giveChange(int change) {
		changeMoney = change;

		cent_200_num = change / Coins.cents_200;
		change = change % Coins.cents_200;

		cent_100_num = change / Coins.cents_100;
		change = change % Coins.cents_100;

		cent_50_num = change / Coins.cents_50;
		change = change % Coins.cents_50;

		cent_20_num = change / Coins.cents_20;
		change = change % Coins.cents_20;

		cent_10_num = change / Coins.cents_10;
		change = change % Coins.cents_10;

		cent_5_num = change / Coins.cents_5;
		change = change % Coins.cents_5;

		cent_2_num = change / Coins.cents_2;
		change = change % Coins.cents_2;

		cent_1_num = change / Coins.cents_1;
		change = change % Coins.cents_1;

		StringBuffer coinBuffer = new StringBuffer();
		coinBuffer.append(cent_200_num > 0 ? " <" + cent_200_num + " x 200cents>\n" : "");
		coinBuffer.append(cent_100_num > 0 ? " <" + cent_100_num + " x 100cents>\n" : "");
		coinBuffer.append(cent_50_num > 0 ? " <" + cent_50_num + " x 50cents>\n" : "");
		coinBuffer.append(cent_20_num > 0 ? " <" + cent_20_num + " x 20cents>\n" : "");
		coinBuffer.append(cent_10_num > 0 ? " <" + cent_10_num + " x 10cents>\n" : "");
		coinBuffer.append(cent_5_num > 0 ? " <" + cent_5_num + " x 5cents>\n" : "");
		coinBuffer.append(cent_2_num > 0 ? " <" + cent_2_num + " x 2cents>\n" : "");
		coinBuffer.append(cent_1_num > 0 ? " <" + cent_1_num + " x 1cent>\n" : "");

		SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
		displayPanel.displayMsg("Here is your change: " + (double) changeMoney / 100 + " �.\n" + coinBuffer.toString());
	}

	@Override
	public void removeChange() {
		SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
		displayPanel.displayMsg("Change removed.");
		lock();
	}
}
