package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.Color;
import java.util.concurrent.TimeUnit;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;

public class GraphicProcessor extends GraphicProcessorDevice implements ProcessorDevice {

	int capacity = 100;
	int processTime = 5;

	public GraphicProcessor(String name, int capacity, int processTime, int x, int y, int width, int height, int border, Color color) {
		super(name, x, y, width, height, border, color);
		this.capacity = capacity;
		this.processTime = processTime;
	}

	@Override
	public void streamOut(Device arg0) {
	}

	@Override
	public int streamRate() {
		return 0;
	}

	@Override
	public int getCapacity() {
		return capacity;
	}

	@Override
	public String getProcessingLabel() {
		return null;
	}

	@Override
	public void operateStart() {
		for (int i = 0; i < processTime; i++) {
			blinkOff();
			SwingVM.sleep(1);
			blinkOn();
			SwingVM.sleep(1);
		}
	}

	@Override
	public void operateStop() {
	}

	@Override
	public void streamIn() {
	}
}
