package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.Color;
import java.awt.Dimension;

import javax.swing.JPanel;

public class ExternalDevices extends JPanel {

	SwingNumPad			 numpad;
	SwingCoinAcceptor	 coinAcceptor;
	SwingChangeCase      changeCase;
	SwingProductCase	 productCase;
	SwingDisplayPanel 	 displayPanel;

	public ExternalDevices() {
		this.setBackground(Color.DARK_GRAY);
		this.setPreferredSize(new Dimension(150, 700));
		numpad 	     = new SwingNumPad();
		coinAcceptor = new SwingCoinAcceptor();
		changeCase   = new SwingChangeCase();
		productCase  = new SwingProductCase();
		displayPanel = new SwingDisplayPanel();
		this.add(numpad);
		this.add(coinAcceptor);
		this.add(displayPanel);
		this.add(changeCase);
		this.add(productCase);
		SwingVM.getInstance().addDevice("NUMPAD", numpad);
		SwingVM.getInstance().addDevice("COINACCEPTOR", coinAcceptor);
		SwingVM.getInstance().addDevice("DISPLAYPANEL", displayPanel);
		SwingVM.getInstance().addDevice("CHANGECASE", changeCase);
		SwingVM.getInstance().addDevice("PRODUCTCASE", productCase);
	}

}
