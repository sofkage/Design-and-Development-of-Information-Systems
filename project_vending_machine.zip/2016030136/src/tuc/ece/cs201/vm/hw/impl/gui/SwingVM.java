package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.BasicStroke;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.swing.JFrame;

import containers.DosingContainer;
import containers.FlowContainer;
import containers.MaterialContainer;
import processors.IngredientProcessor;
import recipe.OperateStep;
import recipe.Recipe;
import recipe.RecipeManager;
import recipe.TransferStep;
import tuc.ece.cs201.vm.hw.HardwareMachine;
import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;
import userModules.ProductCase;
import vendingMachine.Consumer;
import vendingMachine.VendingMachine;

public class SwingVM extends JFrame implements HardwareMachine {
	public static final String model = "SwingVM 1.0";
	ExternalDevices ext_devs;
	public InternalDevices in_devs;
	public HashMap<String, Device> devices = new HashMap<String, Device>();

	public static final Color active_color = Color.orange;
	public static final Color deactive_color = Color.lightGray;
	public static final Color fg_color = Color.black;
	public static final Color coffee_color = new Color(109, 97, 60);
	public static final Color sugar_color = new Color(255, 230, 230);
	public static final Color cinammon_color = new Color(210, 105, 30);
	public static final Color chocolate_color = new Color(123, 63, 0);
	public static final Color water_color = new Color(0, 119, 190);
	public static final Color milk_color = new Color(220, 217, 205);
	public static final Color small_cup_color = new Color(110, 217, 105);
	public static final Color big_cup_color = new Color(220, 117, 105);

	public static final Color boiler_color = new Color(200, 200, 200);
	public static final Color mixer_color = new Color(200, 200, 200);
	public static final Color buffer_color = new Color(200, 200, 200);
	public static final Color cooler_color = new Color(200, 200, 200);

	final static BasicStroke stroke = new BasicStroke(1.0f);
	final static BasicStroke dstroke = new BasicStroke(2.0f);
	final static BasicStroke wstroke = new BasicStroke(8.0f);

	final static float dash1[] = { 5.0f };
	final static BasicStroke dashed = new BasicStroke(1.0f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10.0f, dash1,
			0.0f);

	private static SwingVM vm;

	private SwingVM() {
		super(model);
		this.setVisible(true);
		this.setResizable(false);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	private void initDevices() {
		ext_devs = new ExternalDevices();
		in_devs = new InternalDevices();

		Container pcont = this.getContentPane();
		pcont.add(ext_devs, BorderLayout.LINE_START);
		pcont.add(in_devs, BorderLayout.LINE_END);
		pack();
	}

	public static SwingVM getInstance() {
		if (vm == null) {
			vm = new SwingVM();
			vm.initDevices();
		}
		return vm;
	}

	public static void sleep(int secs) {
		try {
			Thread.sleep(secs * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	public void refresh() {
		this.repaint();
	}

	public void addDevice(String name, Device mod) {
		devices.put(name, mod);
	}

	public Device getDevice(String name) {
		return devices.get(name);
	}

	@Override
	public String getModel() {
		return model;
	}

	@Override
	public List<Device> listDevices() {
		return new ArrayList<>(devices.values());
	}

	public static void main(String[] args) throws Exception {
		
		VendingMachine         vm = VendingMachine.getInstance();
		SwingVM svm = SwingVM.getInstance();
		vm.initMachine(svm);

		RecipeManager rManager = new RecipeManager();
		rManager.loadRecipes();

		//
		SwingNumPad nump = (SwingNumPad) SwingVM.getInstance().getDevice("NUMPAD");
		SwingCoinAcceptor coinAcceptor = (SwingCoinAcceptor) SwingVM.getInstance().getDevice("COINACCEPTOR");
		SwingChangeCase changeCase = (SwingChangeCase) SwingVM.getInstance().getDevice("CHANGECASE");
		SwingProductCase productCase = (SwingProductCase) SwingVM.getInstance().getDevice("PRODUCTCASE");
		SwingDisplayPanel displayPanel = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
		SwingVM.sleep(3);

		displayPanel.displayMenu(rManager.getRecipes());

		do {
			nump.reset();
			coinAcceptor.reset();
			changeCase.reset();
			
			nump.unLock();
			coinAcceptor.unLock();
			int code = nump.readDigit("");
			System.out.println("digit pressed = " + code);
			nump.lock();
			coinAcceptor.lock();

			Recipe recipe = rManager.getRecipe(code);

			changeCase.unLock();
			if (coinAcceptor.inputMoney < recipe.getCost()) {
				displayPanel.displayMsg("Not enough money entered for your order. Please try again.");
				SwingVM.sleep(3);
				changeCase.giveChange(coinAcceptor.inputMoney);
			} else {
				changeCase.giveChange(coinAcceptor.inputMoney - recipe.getCost());

				ProductCase pc = new ProductCase(productCase);
				pc.prepareProduct(recipe.getType(), recipe.getName(), recipe.getCost());

				for (int i = 0; i < recipe.steps.size(); i++) {
					if (recipe.steps.get(i).getClass().equals(OperateStep.class)) {
						OperateStep operateStep = (OperateStep) recipe.steps.get(i);
						if (operateStep.getProcessor().equals("BOILER")) {
							GraphicProcessor boiler = (GraphicProcessor) SwingVM.getInstance().getDevice("BOILER");
							boiler.open();
							boiler.operateStart();
							boiler.operateStop();
							boiler.close();
						} else if (operateStep.getProcessor().equals("MIXER")) {
							GraphicProcessor mixer = (GraphicProcessor) SwingVM.getInstance().getDevice("MIXER");
							mixer.open();
							mixer.operateStart();
							mixer.operateStop();
							mixer.close();
						} else if (operateStep.getProcessor().equals("BUFFER")) {
							GraphicProcessor buffer = (GraphicProcessor) SwingVM.getInstance().getDevice("BUFFER");
							buffer.open();
							buffer.operateStart();
							buffer.operateStop();
							buffer.close();
						} else if (operateStep.getProcessor().equals("COOLER")) {
							GraphicProcessor cooler = (GraphicProcessor) SwingVM.getInstance().getDevice("COOLER");
							cooler.open();
							cooler.operateStart();
							cooler.operateStop();
							cooler.close();
						}
					} else if (recipe.steps.get(i).getClass().equals(TransferStep.class)) {
						TransferStep transferStep = (TransferStep) recipe.steps.get(i);

						GraphicDosingContainer conFrom = null;

						if (transferStep.getFrom().equals("POWDERS")) {
							if (transferStep.getWhat().equals("SUGAR"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("SUGAR");
							else if (transferStep.getWhat().equals("CINNAMON"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("CINNAMON");
							else if (transferStep.getWhat().equals("CHOCOLATE"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("CHOCOLATE");
							else if (transferStep.getWhat().equals("COFFEE"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("COFFEE");
						} else if (transferStep.getFrom().equals("LIQUIDS")) {
							if (transferStep.getWhat().equals("MILK"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("MILK");
							else if (transferStep.getWhat().equals("WATER"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("WATER");
						} else if (transferStep.getFrom().equals("CUPS")) {
							if (transferStep.getWhat().equals("BIGCUP"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("BIGCUP");
							else if (transferStep.getWhat().equals("SMALLCUP"))
								conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("SMALLCUP");
						}

						if (conFrom != null) {
							conFrom.open();
							for(int k = 0; k < transferStep.getQuantity()/conFrom.doseSize();k++)
								conFrom.releaseDose(null);
							SwingVM.sleep(2);
							conFrom.close();
						}
						
					}
				}
				
				productCase.setFinalProduct(pc.getProduct());
				productCase.unLock();
			}
		} while (true);
	}
}
