package tuc.ece.cs201.vm.hw.impl.gui;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;

import javax.swing.JPanel;

public class InternalDevices extends JPanel {

	GraphicContainer coffeeContainer;
	GraphicContainer sugarContainer;
	GraphicContainer cinnamonContainer;
	GraphicContainer chocolateContainer;
	GraphicContainer milkContainer;
	GraphicContainer waterContainer;
	GraphicContainer bigCupContainer;
	GraphicContainer smallCupContainer;

	GraphicProcessorDevice boilerProcessor;
	GraphicProcessorDevice mixerProcessor;
	GraphicProcessorDevice bufferProcessor;
	GraphicProcessorDevice coolerProcessor;

	int gridWidth;
	int gridHeight;

	public InternalDevices() {
		Dimension d = new Dimension(700, 700);
		this.setPreferredSize(d);

		gridWidth = d.width / 6;
		gridHeight = d.height / 4;

		coffeeContainer = new GraphicDosingContainer("COFFEE", 100, 5, 0, 0, gridWidth, gridHeight, 10,
				SwingVM.coffee_color);
		SwingVM.getInstance().addDevice("COFFEE", coffeeContainer);

		sugarContainer = new GraphicDosingContainer("SUGAR", 100, 5, gridWidth, 0, gridWidth, gridHeight, 10,
				SwingVM.sugar_color);
		SwingVM.getInstance().addDevice("SUGAR", sugarContainer);

		cinnamonContainer = new GraphicDosingContainer("CINNAMON", 100, 5, 2 * gridWidth, 0, gridWidth, gridHeight, 10,
				SwingVM.cinammon_color);
		SwingVM.getInstance().addDevice("CINNAMON", cinnamonContainer);

		chocolateContainer = new GraphicDosingContainer("CHOCOLATE", 100, 5, 3 * gridWidth, 0, gridWidth, gridHeight,
				10, SwingVM.chocolate_color);
		SwingVM.getInstance().addDevice("CHOCOLATE", chocolateContainer);

		milkContainer = new GraphicDosingContainer("MILK", 100, 5, 0, gridHeight, gridWidth, gridHeight, 10,
				SwingVM.milk_color);
		SwingVM.getInstance().addDevice("MILK", milkContainer);

		waterContainer = new GraphicDosingContainer("WATER", 100, 5, gridWidth, gridHeight, gridWidth, gridHeight, 10,
				SwingVM.water_color);
		SwingVM.getInstance().addDevice("WATER", waterContainer);

		smallCupContainer = new GraphicDosingContainer("SMALLCUP", 50, 1, 2 * gridWidth, 3 * gridHeight, gridWidth,
				gridHeight, 10, SwingVM.small_cup_color);
		SwingVM.getInstance().addDevice("SMALLCUP", smallCupContainer);

		bigCupContainer = new GraphicDosingContainer("BIGCUP", 50, 1, 3 * gridWidth, 3 * gridHeight, gridWidth,
				gridHeight, 10, SwingVM.big_cup_color);
		SwingVM.getInstance().addDevice("BIGCUP", bigCupContainer);

		boilerProcessor = new GraphicProcessor("BOILER", 100, 5, 4 * gridWidth, 2 * gridHeight, gridWidth, gridHeight,
				10, SwingVM.boiler_color);
		SwingVM.getInstance().addDevice("BOILER", boilerProcessor);

		mixerProcessor = new GraphicProcessor("MIXER", 100, 5, 2 * gridWidth, 2 * gridHeight, gridWidth, gridHeight, 10,
				SwingVM.mixer_color);
		SwingVM.getInstance().addDevice("MIXER", mixerProcessor);

		bufferProcessor = new GraphicProcessor("BUFFER", 100, 5, 0, 2 * gridHeight, gridWidth, gridHeight, 10,
				SwingVM.buffer_color);
		SwingVM.getInstance().addDevice("BUFFER", bufferProcessor);

		coolerProcessor = new GraphicProcessor("COOLER", 100, 5, 5 * gridWidth, 2 * gridHeight, gridWidth, gridHeight,
				10, SwingVM.cooler_color);
		SwingVM.getInstance().addDevice("COOLER", coolerProcessor);
	}

	@Override
	public void paintComponent(Graphics g) {
		// Get the subclass Graphics2D
		Graphics2D g2 = (Graphics2D) g;

		// Draw all Graphic Devices in Internal Devices
		coffeeContainer.draw(g2);
		sugarContainer.draw(g2);
		cinnamonContainer.draw(g2);
		chocolateContainer.draw(g2);
		milkContainer.draw(g2);
		waterContainer.draw(g2);
		bigCupContainer.draw(g2);
		smallCupContainer.draw(g2);

		boilerProcessor.draw(g2);
		mixerProcessor.draw(g2);
		bufferProcessor.draw(g2);
		coolerProcessor.draw(g2);

		// Draw the grid with dashes lines
		g2.setStroke(SwingVM.dashed);

		for (int h = gridHeight; h < getSize().getHeight(); h += gridHeight)
			g.drawLine(0, h, (int) getSize().getWidth(), h);

		for (int w = gridWidth; w < getSize().getWidth(); w += gridWidth)
			g.drawLine(w, 0, w, (int) getSize().getHeight());
		// -------------------------------

		g2.setStroke(SwingVM.stroke);
	}
}
