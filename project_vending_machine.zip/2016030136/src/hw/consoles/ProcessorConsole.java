package hw.consoles;

import java.util.List;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;

public class ProcessorConsole extends FlowContainerConsole implements ProcessorDevice {

	public ProcessorConsole(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String getProcessingLabel() {   
		String label;
		if (this.getName().equals("Cooler")){
			label="COOL";
			return label;
		}
		if (this.getName().equals("Boiler")){
			label="HOT";
			return label;
		}
		if (this.getName().equals("Mixer")){
			label="MIXED";
			return label;
		}
		if (this.getName().equals("Buffer")){
			label="FIXED";
			return label;
		}
		return null;
		
	}

	@Override
	public void operateStart() {
		System.out.println(super.getName() +" started operating");  
	}

	@Override
	public void operateStop() {
		System.out.println(super.getName() + " stopped operating");

		
	}

	@Override
	public void streamIn() {
		System.out.println(super.getName()+ " streamed in!");
	}

	
	
}
