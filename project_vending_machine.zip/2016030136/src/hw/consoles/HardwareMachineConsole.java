package hw.consoles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.logging.ConsoleHandler;

import processors.IngredientProcessor;
import tuc.ece.cs201.vm.hw.HardwareMachine;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;

public class HardwareMachineConsole implements HardwareMachine{
	
//	methodos arxokopoihsh kai connect
//	get poweders conn get blender
//	
	public HashMap<String, Device> devs ;
	private boolean loaded = false;
	
	public HardwareMachineConsole() {
		
		this.devs = new HashMap<>();
	

	ChangeCaseConsole changeCase	  		 = new ChangeCaseConsole("Change Case", DeviceType.ChangeCase);
	CoinAcceptorConsole coinAcceptor 		 = new CoinAcceptorConsole("Coin Acceptor", DeviceType.CoinReader);
	DisplayConsole displayConsole 	 		 = new DisplayConsole("Display Console", DeviceType.Display);
	NumPadConsole numPadConsole 	 		 = new NumPadConsole("Num Pad", DeviceType.NumPad);
	ProductCaseConsole productCaseConsole	 = new ProductCaseConsole("Product Case", DeviceType.ProductCase);
	
	this.addDevices(changeCase);
	this.addDevices(coinAcceptor);
	this.addDevices(displayConsole);
	this.addDevices(numPadConsole);
	this.addDevices(productCaseConsole);

	
	DispenserConsole<FlowContainerConsole> dispenserDeviceFlow = new DispenserConsole<>("Liquid Dispenser", DeviceType.FlowDispenser);
	dispenserDeviceFlow.addContainer(new FlowContainerConsole("Water", DeviceType.FlowContainer, 2000));
	dispenserDeviceFlow.addContainer(new FlowContainerConsole("Milk", DeviceType.FlowContainer, 2000));
	
	this.addDevices(dispenserDeviceFlow);
	
	DispenserConsole<DosingContainerConsole> dispenserDeviceDosing = new DispenserConsole<>("Powder Dispenser", DeviceType.DosingDispenser);
	dispenserDeviceDosing.addContainer(new DosingContainerConsole("Sugar", DeviceType.DosingContainer, 930));
	dispenserDeviceDosing.addContainer(new DosingContainerConsole("Cinnamon", DeviceType.DosingContainer, 1000));
	dispenserDeviceDosing.addContainer(new DosingContainerConsole("Coffee", DeviceType.DosingContainer, 50));
	dispenserDeviceDosing.addContainer(new DosingContainerConsole("Chocolate", DeviceType.DosingContainer, 1000));
	
	this.addDevices(dispenserDeviceDosing);

	DispenserConsole<MaterialContainerConsole> dispenserDeviceMaterial = new DispenserConsole<>("Material Dispenser", DeviceType.MaterialDispenser);
	dispenserDeviceMaterial.addContainer(new MaterialContainerConsole("Smallcup", DeviceType.MaterialContainer, 150));
	dispenserDeviceMaterial.addContainer(new MaterialContainerConsole("Bigcup", DeviceType.MaterialContainer, 350));
			
	this.addDevices(dispenserDeviceMaterial);
	
	//ProcessorConsole boiler = new  ProcessorConsole("Boiler", DeviceType.Processor, 2000);
	
	this.addDevices(new ProcessorConsole("Boiler", DeviceType.Processor, 2000));
	this.addDevices(new ProcessorConsole("Blender", DeviceType.Processor, 2000));
	this.addDevices(new ProcessorConsole("Buffer", DeviceType.Processor, 2000));
	this.addDevices(new ProcessorConsole("Cooler", DeviceType.Processor, 2000));
	this.addDevices(new ProcessorConsole("Mixer", DeviceType.Processor, 2000));
	
	for (int i=0 ; i<dispenserDeviceDosing.containers.size();i++) {
		this.addDevices((DeviceConsole) dispenserDeviceDosing.containers.get(i));}
		for (int i=0 ; i<	dispenserDeviceDosing.containers.size();i++) {
			this.addDevices((DeviceConsole)	dispenserDeviceDosing.containers.get(i));}
		for (int i=0 ; i<dispenserDeviceMaterial.containers.size();i++) {
			this.addDevices((DeviceConsole) dispenserDeviceMaterial.containers.get(i));}
		for (int i=0 ; i<dispenserDeviceFlow.containers.size();i++) {
			this.addDevices((DeviceConsole) dispenserDeviceFlow.containers.get(i));}
	
	
		
	
	
	}
	
	
	@Override
	public String getModel() {
		return "Super Duper Machine";
	}

	@Override
	public ArrayList<Device> listDevices() {

	     return new ArrayList<>(this.devs.values());
	}

	public void addDevices(DeviceConsole d) {
		devs.put(d.getName(), d);
	
	}



}
