package hw.consoles;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import recipe.Recipe;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;

	public abstract class DeviceConsole implements Device{
		
		protected String name;
		protected DeviceType type;
	    protected boolean loaded = false;
		private ArrayList<Device> deviceConnectedList = new ArrayList<>();
		
		

		public DeviceConsole(String name, DeviceType type) {
			super();
			this.name = name;
			this.type = type;
		}

		@Override
		public void connect(Device device) {
			deviceConnectedList.add(device);
			System.out.println(device.getName()+ " connected\n");
		}

		@Override
		public void disconnect(Device device) {
			deviceConnectedList.remove(device);
			System.out.println(device.getName()+ " disconnected\n");
			
		}

		@Override
		public void disconnectAll() {
			deviceConnectedList.clear();
			System.out.println("All device disconnected\n");

		}

		@Override
		public String getName() {
			return name;
		}

		@Override
		public DeviceType getType() {
			return type;
		}

		
		  public  List<Device> listConnectedDevices() {

		        return deviceConnectedList;
		    }
		
	}


