package hw.consoles;


import java.util.ArrayList;

import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.DeviceType;

public class ContainerConsole extends DeviceConsole implements ContainerDevice {
	

	private int capacity;
	protected boolean  opened;

	ArrayList<ContainerDevice>  contList = new ArrayList<>();
	
	
	public ContainerConsole(String name, DeviceType type, int capacity) {
		super(name, type);
		this.capacity = capacity;
	}

	@Override
	public void close() {
		opened = false;
		System.out.println(this.getName()+ " closed");
		
	}



	@Override
	public boolean isOpen() {
		return opened;
	}

	@Override
	public void open() {
		opened  = true;
		System.out.println(this.getName()+ " opened");
	}

	@Override
	public int getCapacity() {
		return this.capacity;
	}

	

}
