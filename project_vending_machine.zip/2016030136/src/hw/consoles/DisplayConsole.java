package hw.consoles;

import java.util.List;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;


public class DisplayConsole extends DeviceConsole implements DisplayDevice {

	public DisplayConsole(String name, DeviceType type) {
		super(name, type);
	}

	@Override
	public void clear() {
		System.out.flush();
		System.out.println("Cleared All");
		
	}

	@Override
	public void displayMsg(String txt) {
		System.out.println(txt);
	}


}
