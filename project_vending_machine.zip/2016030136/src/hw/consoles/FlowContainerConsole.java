package hw.consoles;

import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;

public class FlowContainerConsole extends ContainerConsole implements FlowContainerDevice {

	public FlowContainerConsole(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void streamOut(Device toConnectedDevice) {
		System.out.println(super.getName() +" streamed out to "+toConnectedDevice.getName());
		
	}

	@Override
	public int streamRate() {          //to kanei alliws
		return 5;
	//	return streamRate();
	}

}
