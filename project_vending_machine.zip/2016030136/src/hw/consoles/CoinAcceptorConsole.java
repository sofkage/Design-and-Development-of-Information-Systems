package hw.consoles;


import tuc.ece.cs102.util.StandardInputRead;
import tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice;
import tuc.ece.cs201.vm.hw.device.DeviceType;

public class CoinAcceptorConsole extends LockableConsole implements CoinAcceptorDevice {


	public CoinAcceptorConsole(String name, DeviceType type) {
		super(name, type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int acceptCoin(int subTotal) {  //scanarei coin kai to epistrefei
		StandardInputRead str = new StandardInputRead();
		subTotal += str.readPositiveInt("Please enter the coins: ");
		return subTotal;
	}

	
}
