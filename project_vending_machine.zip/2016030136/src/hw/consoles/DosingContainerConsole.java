package hw.consoles;


import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;

public class DosingContainerConsole extends ContainerConsole implements DosingContainerDevice {

	
	public DosingContainerConsole(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int doseSize() {
		int dose = 5;
		return dose;
	}

	@Override
	public void releaseDose(Device toConnectedDevice) {
		System.out.println(super.getName() + " released "+this.doseSize()+ "gr to " +toConnectedDevice.getName());
	}
	
	
}
