package hw.consoles;



import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;
import tuc.ece.cs201.vm.hw.device.DeviceType;

public class ChangeCaseConsole extends LockableConsole implements ChangeCaseDevice{

	public ChangeCaseConsole(String name, DeviceType type) {
		super(name, type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void giveChange(int coin) {
		System.out.println("Here are your change: " +coin+ "�");
	 }

	@Override
	public void removeChange() {
		System.out.println("Change removed");

		
	}

}
