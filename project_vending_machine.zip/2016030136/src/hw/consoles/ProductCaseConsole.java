package hw.consoles;

import java.util.ArrayList;

import consumambles.Material;
import consumambles.ProcessedIngredient;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;

public class ProductCaseConsole extends LockableConsole implements ProductCaseDevice{
	
	public ProductCaseConsole(String name, DeviceType type) {
		super(name, type);
		// TODO Auto-generated constructor stub
	}

	ArrayList<ProcessedIngredient> 	 ingredientList = new ArrayList<>();
	ArrayList<Material>  			   materialList = new ArrayList<>();
	
 
	@Override
	public void loadIngredient(String ingredientType) {

			System.out.println(ingredientType + " loaded  "); 
	}


	@Override
	public void putMaterial(String materialType) {
		System.out.println(materialType + " was added to product ");
	}


}
