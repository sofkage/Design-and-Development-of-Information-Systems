package hw.consoles;



import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;

public  class MaterialContainerConsole extends ContainerConsole implements MaterialContainerDevice{

	public MaterialContainerConsole(String name, DeviceType type, int capacity) {
		super(name, type, capacity);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void releaseMaterial(Device toConnectedDevice) {
		System.out.println( "Material released to " +toConnectedDevice.getName()  );
	}


}
