package hw.consoles;

import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.LockableDevice;

public abstract class LockableConsole extends DeviceConsole implements LockableDevice {
	
	public LockableConsole(String name, DeviceType type) {
		super(name, type);
		// TODO Auto-generated constructor stub
	}

	protected boolean  locked;
	
	
	public boolean isLocked() {
		return locked;
	}

	public void lock() {
		locked=true;
		System.out.println(this.getName()+ " locked");
		
	}

	public void unLock() {
		 locked=false;
		System.out.println(this.getName()+ " unlocked");

	}

}
 