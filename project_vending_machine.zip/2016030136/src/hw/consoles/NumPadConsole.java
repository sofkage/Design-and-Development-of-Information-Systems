package hw.consoles;

import tuc.ece.cs102.util.StandardInputRead;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;

public class NumPadConsole extends LockableConsole implements NumPadDevice{

	public NumPadConsole(String name, DeviceType type) {
		super(name, type);
		// TODO Auto-generated constructor stub
	}

	@Override
	public int readDigit(String currentCode) {		
		StandardInputRead reader = new StandardInputRead();
		
		currentCode = reader.readString("Enter the digits. Enter one digit at a time and then press Enter: ");
		
		return Integer.parseInt(currentCode);
	}

	
}
