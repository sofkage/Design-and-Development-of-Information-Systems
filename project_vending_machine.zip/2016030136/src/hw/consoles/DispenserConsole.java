package hw.consoles;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.DeviceType;
import tuc.ece.cs201.vm.hw.device.DispenserDevice;



public class DispenserConsole<T extends ContainerDevice> extends DeviceConsole implements DispenserDevice<T> {
	
	ArrayList<T> containers;
	 
	//me thn parametrikopoihsh
	

		public DispenserConsole(String name, DeviceType type) {
		super(name, type);
		this.containers = new ArrayList<T>();
	}
		

		public DispenserConsole(String name, DeviceType type, ArrayList<T> containers) {
			super(name, type);
			this.containers = new ArrayList<>();
		}


		@Override
		public void addContainer(ContainerDevice containerDevice) {
			this.containers.add((T) containerDevice);
			}
	
		@Override
		public List<T> listContainers() {  		
			return    containers;  //??? //giati thelei list T
		}
	
		@Override
		public void prepareContainer(ContainerDevice containerDevice) {
			
			for( int i = 0; i<containers.size(); i++) {
				if(containers.get(i)==containerDevice) {
					System.out.println("Preparing "+containerDevice.getName());
				}else {
					System.out.println("Error 404: Container not found");
				}
			}
			
		}
	
		@Override
		public void removeContainer(String name) {
	          for ( int i=0;i< containers.size();i++) {
	        	  if(containers.get(i).getName().equals(name))
	        	  {
	        		  containers.remove(i);
	        	  }
	        		  
	          }
		}
	
		
	}