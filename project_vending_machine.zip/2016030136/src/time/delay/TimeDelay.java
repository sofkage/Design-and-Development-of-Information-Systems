package time.delay;

 import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
 
 
public class TimeDelay {
	 
	public void waitFor(int duration) throws TimeoutException  {   //na thn ylopoihsw alliws
        try {
			TimeUnit.SECONDS.sleep(duration);		//na valw allo arithmo mesa stis synartiseis poy thn kalw
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

}
