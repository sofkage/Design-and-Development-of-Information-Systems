package exceptions;

public class NotExistantConsumable extends Exception {

	public NotExistantConsumable(String message) {
		super(message);
		}
	

}
