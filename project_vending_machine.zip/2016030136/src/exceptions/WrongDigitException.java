package exceptions;

public class WrongDigitException extends Exception {

}
