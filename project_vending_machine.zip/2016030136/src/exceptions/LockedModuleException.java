package exceptions;

public class LockedModuleException extends Exception {

	public LockedModuleException(String string) {
	}
	


}
