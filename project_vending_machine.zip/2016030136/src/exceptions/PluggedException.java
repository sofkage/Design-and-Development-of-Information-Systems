package exceptions;

public class PluggedException extends Exception {

	public PluggedException(String message) {
		super(message);
		
	}
}
