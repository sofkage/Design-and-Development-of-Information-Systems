package exceptions;

public class MalformedRecipeException extends Exception {
    public MalformedRecipeException(String message) {
        super(message);
    }
}
