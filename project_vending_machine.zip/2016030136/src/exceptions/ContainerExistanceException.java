package exceptions;

public class ContainerExistanceException extends Exception {
	

}
