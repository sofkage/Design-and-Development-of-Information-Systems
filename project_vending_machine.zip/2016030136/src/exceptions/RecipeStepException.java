package exceptions;

public class RecipeStepException extends Exception {
	
	public RecipeStepException(String message) {
		super(message);
	}

}
