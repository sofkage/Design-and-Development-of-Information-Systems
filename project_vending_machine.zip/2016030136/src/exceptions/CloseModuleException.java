package exceptions;

public class CloseModuleException extends Exception {

	public CloseModuleException(String string) {
	}
}
