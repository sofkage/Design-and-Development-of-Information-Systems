package consumambles;

public abstract class Ingredient extends Consumable {

	
	public Ingredient(String name, int quantity) {
		super(name, quantity);
	}

}
