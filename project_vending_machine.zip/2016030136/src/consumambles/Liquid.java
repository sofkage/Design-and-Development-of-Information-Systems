package consumambles;

public class Liquid extends Ingredient {

	public Liquid(String name, int quantity) {
		super(name, quantity);
		// TODO Auto-generated constructor stub
	}

}
