package consumambles;

public class Powder extends Ingredient {

	public Powder(String name, int q) {
		super(name, q);		
	}
	
}