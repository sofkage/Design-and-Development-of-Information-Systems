package consumambles;

public class Cup extends Material{

	public Cup(String name, int quantity,String size) {
		super(name, quantity);
		this.size = size;
	}

	private String size;

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
}
