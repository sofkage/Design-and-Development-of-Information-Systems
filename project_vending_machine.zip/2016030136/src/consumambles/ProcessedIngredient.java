package consumambles;
import java.util.Collection;
import java.util.HashMap;

public class ProcessedIngredient extends Ingredient{

	public HashMap<String,Ingredient> ingre = new HashMap<>();


	public ProcessedIngredient(String name, int quantity) {
		super(name, quantity);
	}

	public void addIngredient(Ingredient i){  
		ingre.put(i.getName(),i);
		this.setQuantity(this.getQuantity()+i.getQuantity());
		
	}


	@Override
	public String getName() {		
		String name = this.name + "(";
		Collection<Ingredient> col = ingre.values();
		
	
		for(Ingredient ing : col){
			name = name + ing.getName()+","; //+"["+ing+"]" ayto einai to noumero toy
		}
		name = name.substring(0,name.length()-1);
		name += ")";
		return name;
	}

	
	public void resetIngredient(){     //tha deixnei se diko so uhashmap kai tha afhsei to diko moy hsyxo
		ingre = new HashMap<String,Ingredient>();
	}
	

	@Override
	public ProcessedIngredient clone() throws CloneNotSupportedException {
		ProcessedIngredient cons = (ProcessedIngredient)super.clone();
		cons.resetIngredient();				//vazw antigrafa twn dikwn mou ingre
		for(Ingredient i: ingre.values()){
			cons.addIngredient((Ingredient)i.clone());  //kane clone kai ton pro
		}
		return cons;
	}

	
	
}
