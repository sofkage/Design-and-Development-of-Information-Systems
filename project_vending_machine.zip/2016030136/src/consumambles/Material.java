package consumambles;

public abstract class Material extends Consumable {

	public Material(String name, int quantity) {
		super(name, quantity);
	}

}
