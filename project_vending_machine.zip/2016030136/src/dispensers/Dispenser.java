package dispensers;


import containers.Container;
import exceptions.ContainerExistanceException;
import vendingMachine.Consumer;
import vendingMachine.Pluggable;
import vendingMachine.Provider;

public interface Dispenser extends Pluggable {
	

	public Provider prepareContainer(String conName, Consumer conRef) throws ContainerExistanceException;
	public void addContainer (Container container);
	public Container removeContainer(String conName);
	public int getCurrentQuantity(String contName);  
	
}
