package dispensers;

import java.util.ArrayList;

import containers.Container;
import exceptions.ContainerExistanceException;
import exceptions.PluggedException;
import processors.IngredientProcessor;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DispenserDevice;
import userModules.Module;
import vendingMachine.Consumer;
import vendingMachine.Provider;

public class ConsumableDispenser<T extends ContainerDevice> extends Module<DispenserDevice> implements Dispenser{
				

	public ConsumableDispenser( DispenserDevice dev) {
		super( dev);
		// TODO Auto-generated constructor stub
	}

	private ArrayList<Consumer>   lcons = new ArrayList<>();
	private ArrayList<Container<?>>  lcont = new ArrayList<>();
	protected boolean plugged;
	
	
	@Override
	public void plug(Consumer consumer) {
		plugged = true;
		this.lcons.add(consumer);
		this.device.connect(((Module)consumer).getDevice());
		System.out.println("Consumer plugged");
		
	}
	@Override
	public void unPlug(Consumer consumer) {
		plugged = false;
		this.lcons.remove(consumer);
		this.device.disconnect(((Module)consumer).getDevice());
		System.out.println("Consumer unplugged");
	}
	
	@Override
	public void unPlugAll() {
		plugged = false;
		this.lcons.clear();
		this.device.disconnectAll();
		System.out.println("Unplugged All");
	}
	
	@Override
	public boolean isPlugged() {
		return plugged;
	}
	
	@Override
	public Provider prepareContainer(String conName, Consumer conRef) throws ContainerExistanceException {
		for(int i=0; i<lcont.size(); i++) {
			if(conName.equals(lcont.get(i).getName())){
				try {
					lcont.get(i).plug(conRef);
				} catch (PluggedException e) {
					System.out.println("Couldn't be plugged");
					e.printStackTrace();
				}	
				
				return lcont.get(i);
			}else {
				System.out.println("Not match.");
				return null;
			}
		}
		
		return null;
	}
	
	@Override
	public void addContainer(Container container) {
		this.lcont.add(container);
		System.out.println(container.getName()+ " Container added.");
	}
	
	@Override
	public Container removeContainer(String conName) {   
		int i;
		for (i=0;i<lcont.size();i++) {
            if(conName.equals(lcont.get(i).getName()))	{
                       	
            	lcont.remove(lcont.get(i));
            	System.out.println(conName+" Container removed");
            }
		}
	    return lcont.get(i);
	}
	
	@Override
	public int getCurrentQuantity(String contName) {
		int i;
		for ( i=0; i<lcont.size();i++) {
			if(contName.equals(lcont.get(i).getName())) {
				System.out.println("Current quantity: "+lcont.get(i).getContCapacity());
			}
		}
		return lcont.get(i).getContCapacity();
	}

}
