package userModules;

import exceptions.LockedModuleException;
import tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice;

public class CoinReader extends Module<CoinAcceptorDevice> {
	

	public CoinReader(CoinAcceptorDevice dev) {
		super(dev);
	}


	public int receiveMoney(int min) throws LockedModuleException {
		int money = 0;

		this.device.unLock();
		
		if(this.device.isLocked()){
			throw new LockedModuleException("Locked");
		}
		
		System.out.println("Please enter " +min+ "�");
		while (money<min) {
			money = device.acceptCoin(money);
			int diafora = min - money;
			if(diafora < 0)
				return money;
			else 
				System.out.println("Enter "+diafora+ " more �");
		}
		
		this.device.lock();
		return money; 
		}
}

