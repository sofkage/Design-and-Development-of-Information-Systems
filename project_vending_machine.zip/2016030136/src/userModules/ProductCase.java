package userModules;

import java.util.ArrayList;

import builder.DefaultDrinkBuilder;
import builder.Product;
import builder.ProductBuilder;
import consumambles.Consumable;
import consumambles.Ingredient;
import consumambles.Material;
import exceptions.LockedModuleException;
import exceptions.NotExistantConsumable;
import exceptions.RecipeStepException;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;
import vendingMachine.Consumer;

public class ProductCase extends Module<ProductCaseDevice> implements Consumer {    
	
	private ProductBuilder pBuilder;
	private Consumable con;
	public ArrayList<Consumable> loadCons = new ArrayList<>();
	private Product finalProduct;

	
	public ProductCase(ProductCaseDevice dev) {
		super(dev);
		this.name = dev.getName();
	}

	public void setpBuilder(ProductBuilder pBuilder) {
		this.pBuilder = pBuilder;
	}


	public Product getProduct() throws RecipeStepException  { 	 // pote ayto einai etoimo, o builder prepei na prostateyei, mporw builder factory
		return pBuilder.getProduct();
	}

	@Override
	public void load(Consumable con) throws NotExistantConsumable {	
		device.loadIngredient(con.getName());
		try {
			this.pBuilder.addConsumable(con);
		} catch (RecipeStepException e) {
			e.printStackTrace();
		}
	}

	@Override
	public boolean accepts(Consumable consumable) {  
		
		if (consumable instanceof Material) {
			System.out.println("Accepted");
			return true;
		}
		return false;
	}
	
	public String getNameProduct() {
		
		try {
			finalProduct = this.getProduct();
		} catch (RecipeStepException e) {
			e.printStackTrace();
		}

		String name = "Product(";
		for(int i=0;i<finalProduct.consumables.size();i++) {
			name = name + finalProduct.consumables.get(i).getName() +",";
	
		}
		name = name.substring(0,name.length()-1);
		return name+")";		
		
	}
	
	public void prepareProduct(String type,String name, int cost) {
		if(type.equals(" DefaultDrink")) {   //mporei na exw ki alla types, nees prodiagrafes kai tha kanw ayton new, klhronomoun idia logikh
			this.pBuilder = new DefaultDrinkBuilder();
			this.pBuilder.setCost(cost);
			this.pBuilder.setName(name);
		}else {
			System.out.println("builder not found");
		}
	}
}





