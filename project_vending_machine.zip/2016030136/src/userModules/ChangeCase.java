package userModules;

import exceptions.LockedModuleException;
import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;

public class ChangeCase extends Module<ChangeCaseDevice>{

	public ChangeCase( ChangeCaseDevice dev) {
		super( dev);
	}

	public void setChange(int change) throws LockedModuleException {
		
		this.device.unLock();
		
		if(this.device.isLocked()){
			throw new LockedModuleException("Locked");
		}
		
		this.device.giveChange(change);
		this.device.lock();
	}
	
	public void removeChange() throws LockedModuleException {
		
		this.device.unLock();
		
		if(this.device.isLocked()){
			throw new LockedModuleException("Locked");
		}
		
		this.device.removeChange();
		this.device.lock();
	}	
}
