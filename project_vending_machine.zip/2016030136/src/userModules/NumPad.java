package userModules;

import exceptions.LockedModuleException;
import exceptions.WrongDigitException;
import tuc.ece.cs102.util.StandardInputRead;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;;

public class NumPad extends Module<NumPadDevice>{

	private StandardInputRead reader;
	
	public NumPad( NumPadDevice dev) {
		super(dev);
		this.name = dev.getName();
		// TODO Auto-generated constructor stub
	}

	public int readCode(int length) throws LockedModuleException, WrongDigitException {
	
		String codestr = null;
		int code=0;
		
		if(this.device.isLocked())
			this.device.unLock();

		if(this.device.isLocked()){
			throw new LockedModuleException("Locked");
			}
		
		for(int i=0; i<length;i++) {
			 code =  code*10 + this.device.readDigit(codestr);
			 System.out.println(code);
		}
		
		this.device.lock();
		return code; 
	}
	
	
//	public int readDigit() {   // thn vazw sto sf 
//		int digit = -1;
//		
//		while(digit<0 || digit>9) {
//			digit = reader.readPositiveInt("");
//		}
//		
//		return digit;
//	}
	
	
}

