package userModules;

import java.util.ArrayList;

import recipe.Recipe;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;

public class DisplayPanel extends Module<DisplayDevice> {



	public DisplayPanel( DisplayDevice dev) {
		super( dev);
	}

	public void displayMsg(String msg) {
		this.device.displayMsg(msg);
	}
	
	public void displayMenu (ArrayList<Recipe> recipes) {
		if(recipes.isEmpty())
			System.out.println("Recipe list Empty!");
		for(int i=0; i<recipes.size();i++)
			this.device.displayMsg(" " +recipes.get(i).getCode()+ " " +recipes.get(i).getName());
	}

}
