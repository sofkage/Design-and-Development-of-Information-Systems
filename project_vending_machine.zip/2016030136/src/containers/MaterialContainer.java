package containers;


import consumambles.Cup;
import consumambles.Powder;
import exceptions.NotExistantConsumable;
import exceptions.PluggedException;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;
import userModules.ProductCase;
import vendingMachine.Consumer;

public class MaterialContainer<T extends MaterialContainerDevice> extends Container<MaterialContainerDevice> {

//	protected Cup content;

	public MaterialContainer( ContainerDevice dev) {
		super(dev);
		this.name = dev.getName();
		
		this.content = new Cup(dev.getName(), dev.getCapacity(),dev.getName() );//prosomiwsh periexomenou

	}
	
//	public void getMaterial(String name, ContainerDevice dev) {
//		
//		if(dev.getName().equals("Big Cup Container")) {
//			this.content = new Cup("Big Cup", dev.getCapacity(),"Big");
//		}
//		if(dev.getName().equals("Small Cup Container")) {
//			this.content = new Cup("Small Cup", dev.getCapacity(),"Small");
//		}
	//}
	
	public void provide(Consumer conRef, int quantity) {
		
		try {
			ProductCase productCase = (ProductCase)conRef;
			MaterialContainerDevice material = (MaterialContainerDevice) this.device;
			
			material.releaseMaterial(productCase.getDevice());
		

			productCase.load(content.getPart(quantity));
		} catch (NotExistantConsumable e) {
			System.out.println("Consumable doesn't exist.");
			e.printStackTrace();
		}
		try {
			conRef.accepts(content);
		} catch (NotExistantConsumable e) {
    		System.out.println("Couldn't be accepted");
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void provide(Consumer conRef) {
		
		try {
			conRef.load(this.content);
		} catch (NotExistantConsumable e) {
			System.out.println("ERROR 404: Consumable doesn't exist.");
			e.printStackTrace();
		}
		try {
			conRef.accepts(content);
		} catch (NotExistantConsumable e) {
    		System.out.println("Couldn't be accepted");
			e.printStackTrace();
		}
	}

}
