package containers;

import consumambles.Powder;
import exceptions.NotExistantConsumable;
import exceptions.PluggedException;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;
import vendingMachine.Consumer;

public class DosingContainer<T extends DosingContainerDevice> extends Container<DosingContainerDevice> {
	
//	protected Powder content;

	
	public DosingContainer( ContainerDevice dev) {
		super(dev);
		this.content = new Powder(dev.getName(), dev.getCapacity() );//prosomiwsh periexomenou
		this.name = dev.getName();

		}
	

	
//	EDW EINAI H ACCEPT
//	ACCEPT acceptcontent typou class
//	acceptcons = ingre.class
//	ayto to cons einai instance toy 
	
	
//	public void getPowder(String name, ContainerDevice dev ) {   //an einai sugar kai einai brows sugar den xreiazetai na empleketai to mudule me to onoma toy ylikoy
//		if(name.equals("Sugar Container")) {   //
//			content = new Powder("Sugar",dev.getCapacity());
//		}
//		if(name.equals("Coffee Container")) {
//			content = new Powder("Coffee",dev.getCapacity());
//		}
//		if(name.equals("Chocolate Container")) {
//			content = new Powder("Chocolate",dev.getCapacity());
//		}
//		if(name.equals("Cinnamon Container")) {
//			content = new Powder("Cinnamon",dev.getCapacity());
//		}
//		
//		
//	}
	
	public void provide(Consumer conRef, int quantity) {
		
		if (quantity >=0 && quantity <= this.contCapacity) {
			
			if(isPlugged() == false) {
				try {
					plug(conRef);
					
					Container<DosingContainerDevice> cont = (Container<DosingContainerDevice>) conRef;
					DosingContainerDevice dosingDev = (DosingContainerDevice)this.device;
					for(int i = 0; i < (quantity/dosingDev.doseSize()); i++)
						dosingDev.releaseDose(cont.getDevice());
				
					 try {
						conRef.load(content.getPart(quantity));
					} catch (NotExistantConsumable e) {
						System.out.println("Couldn't be loaded! ERROR 404: Consumable doesn't exist.");
						e.printStackTrace();
					}

					}catch(PluggedException p) {
						System.out.println("Couldn't be plugged.");
					}
				}
				try {
					conRef.accepts(content);
				} catch (NotExistantConsumable e) {
	        		System.out.println("Couldn't be accepted");
					e.printStackTrace();
				}
				 try {
					 unPlug(conRef);
				 }catch(PluggedException p) {
					 System.out.println("Couldn't be unplugged");
				 }

				 	this.contCapacity -= quantity;
				
		}else if(quantity > this.contCapacity) {
			System.out.println("Quantity not enough.");
			
		}else 
			System.out.println("Empty Container.");
		
	}

	@Override
	public void provide(Consumer conRef)  {

	    if(isPlugged()==false) {
        	try {
        		plug(conRef);
        		Container<DosingContainerDevice> c = (Container<DosingContainerDevice>) conRef;
    			DosingContainerDevice dosing = (DosingContainerDevice) this.device;
    			for(int i=0; i<dosing.doseSize();i++) {
    				dosing.releaseDose(c.getDevice());
    			}
    			
        	}catch(PluggedException p) {
        		System.out.println("Couldn't be plugged");
        	}
        	
	    }try {
				conRef.accepts(content);
			} catch (NotExistantConsumable e) {
        		System.out.println("Couldn't be accepted");
				e.printStackTrace();
			}
        	
        	try {
				conRef.load(content);
			} catch (NotExistantConsumable e) {
        		System.out.println("Couldn't be loaded");
				e.printStackTrace();
			}
        	
			 try {
				 unPlug(conRef);
			 }catch(PluggedException p) {
				 System.out.println("Couldn't be plugged");
			 }

	}
}

