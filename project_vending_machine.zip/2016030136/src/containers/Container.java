 package containers;

import java.util.ArrayList;

import consumambles.Consumable;
import exceptions.NotExistantConsumable;
import exceptions.PluggedException;
import processors.IngredientProcessor;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import userModules.Module;
import vendingMachine.Consumer;
import vendingMachine.Provider;

public abstract class Container<T extends ContainerDevice> extends  Module<ContainerDevice> implements Provider{

	protected int contCapacity;
	protected Consumable content;
	protected ArrayList<Consumer> pluggedConsumers = new ArrayList<>();
	protected boolean plugged;
	
	protected int currentQuantity;
	
	
	
	public Container( ContainerDevice dev) {
		super(dev);
		this.contCapacity = dev.getCapacity();
		this.currentQuantity = dev.getCapacity();
	}


	public int getContCapacity() {
		return contCapacity;
	}


	public void setContCapacity(int contCapacity) {
		this.contCapacity = contCapacity;
	}

	public T getDevice(){
		return (T)device;       
		}


	@SuppressWarnings("unchecked")
	@Override
	public void plug(Consumer consumer) throws PluggedException{
		plugged = true;
		this.pluggedConsumers.add(consumer);
		this.device.connect(((Module<T>) consumer).getDevice());
		System.out.println("Consumer plugged");
		
	}


	@Override
	public void unPlug(Consumer consumer) throws PluggedException{
		plugged = false;
		this.pluggedConsumers.remove(consumer);
		this.device.disconnect(((Module<T>)consumer).getDevice());
		System.out.println("Consumer unplugged");


	}


	@Override
	public void unPlugAll() {
		plugged = false;
		this.pluggedConsumers.clear();
		this.device.disconnectAll();
		System.out.println("Unplugged All");
	}


	@Override
	public boolean isPlugged() {
		return plugged;
	}


	@Override
	public abstract void provide(Consumer confRef, int quantity);
	


	public Consumable getContent() {
		return content;
	}


	public void setContent(Consumable content) {
		this.content = content;
	}


	@Override
	public abstract void provide(Consumer confRef)  ;

	}






