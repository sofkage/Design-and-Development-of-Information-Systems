package containers;


import consumambles.Consumable;
import consumambles.Liquid;
import consumambles.Powder;
import exceptions.NotExistantConsumable;
import exceptions.PluggedException;
import processors.IngredientProcessor;
import tuc.ece.cs201.vm.hw.device.ContainerDevice;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;
import vendingMachine.Consumer;

public class FlowContainer<T extends FlowContainerDevice> extends Container<FlowContainerDevice> {
//	protected Liquid content;

	
	public FlowContainer(FlowContainerDevice dev) {
		super(dev);
		this.name = super.getName();
		this.content = new Liquid(dev.getName(), dev.getCapacity() );//prosomiwsh periexomenou

//		if(dev.getName().equals("Milk Container")) {
//			this.content = new Liquid ("Milk", dev.getCapacity());
//		}
//		if(dev.getName().equals("Water Container")) {
//			this.content = new Liquid ("Water", dev.getCapacity());
//		}
		
	}


	public void provide(Consumer conRef, int quantity) {   ///pou mpainei to streamOut
		
		if (quantity >=0 && quantity <= this.contCapacity) {
			
			try {
				plug(conRef);
        		Container<FlowContainerDevice> cont = (Container<FlowContainerDevice>) conRef;
    			FlowContainerDevice flow = (FlowContainerDevice) this.device;
    			
				this.contCapacity -= quantity;
				System.out.println("Providing quantity " +quantity+ " to" +((IngredientProcessor)conRef).getDevice().getName() ); //flowcont
    			for(int i=0; i<(quantity/flow.streamRate());i++) {
    				flow.streamOut(cont.getDevice());}
    						
			} catch (PluggedException e) {
    				System.out.println("Coulnt't be plugged.");
    				e.printStackTrace();
    			}

				 try {
						conRef.load(content.getPart(quantity));
						
					} catch (NotExistantConsumable e) {
						System.out.println("Coulnt't be loaded.");
						e.printStackTrace();
					}
				 try {
						conRef.accepts(content);
					} catch (NotExistantConsumable e) {
		        		System.out.println("Couldn't be accepted");
						e.printStackTrace();
					}
				 try {
					 unPlug(conRef);
				 }catch(PluggedException p) {
					 System.out.println("Couldn't be plugged");
				 }

				 	this.contCapacity -= quantity;

				
		}else if(quantity > this.contCapacity) {
			System.out.println("Quantity not enough.");
			
		}else 
			System.out.println("Empty Container.");
		
	}



	@Override
	public void provide(Consumer conRef) {
		
		try {
	    		if(isPlugged()==false) {
	    			try {
			    		plug(conRef);
				    }catch(PluggedException p) {
				    	System.out.println("Couldn't be plugged.");
				    }
					conRef.load(content);
	    		}
	    	} catch (NotExistantConsumable e) {
			    	System.out.println("Couldn't be loaded.");
					e.printStackTrace();
			}
			try {
				conRef.accepts(content);
			} catch (NotExistantConsumable e) {
	    		System.out.println("Couldn't be accepted");
				e.printStackTrace();
			}
				
			try {
				unPlug(conRef);
			}catch(PluggedException p) {
				System.out.println("Couldn't be plugged");
			}

	}


}
