package main;


import java.util.HashMap;

import containers.Container;
import containers.DosingContainer;
import containers.FlowContainer;
import containers.MaterialContainer;
import exceptions.LockedModuleException;
import exceptions.RecipeStepException;
import exceptions.WrongDigitException;
import hw.consoles.HardwareMachineConsole;
import processors.IngredientProcessor;
import recipe.OperateStep;
import recipe.Recipe;
import recipe.RecipeManager;
import recipe.TransferStep;
import userModules.ChangeCase;
import userModules.CoinReader;
import userModules.DisplayPanel;
import userModules.Module;
import userModules.NumPad;
import userModules.ProductCase;
import vendingMachine.Consumer;
import vendingMachine.VendingMachine;
import tuc.ece.cs201.vm.hw.impl.gui.GraphicDosingContainer;
import tuc.ece.cs201.vm.hw.impl.gui.GraphicProcessor;
import tuc.ece.cs201.vm.hw.impl.gui.SwingChangeCase;
import tuc.ece.cs201.vm.hw.impl.gui.SwingCoinAcceptor;
import tuc.ece.cs201.vm.hw.impl.gui.SwingDisplayPanel;
import tuc.ece.cs201.vm.hw.impl.gui.SwingNumPad;
import tuc.ece.cs201.vm.hw.impl.gui.SwingProductCase;
import tuc.ece.cs201.vm.hw.impl.gui.SwingVM;;

public class Controller {
	
	public static void main(String[] args) {
		
		VendingMachine         	vm 		= VendingMachine.getInstance();
		HardwareMachineConsole 	hm 		= new HardwareMachineConsole();	//gia na trexei h console
//		SwingVM 				svm 	= SwingVM.getInstance();		//gia na trexoun ta grafika
		
		
//**********INIT MACHINES*********		
//		vm.initMachine(svm);	//gia na trexoun ta grafika
		vm.initMachine(hm);		//gia na trexei h console
		
//********RUN***********		
		run(vm); 				//gia na trexei h console
//		runSwingVm(svm);		//gia na trexoun ta grafika


	}
 
	
	
	public static void run(VendingMachine vm) {
		
//------------Creating Modules
		Module m;
		
		m=vm.modules.get("Display Console");
		DisplayPanel dp = (DisplayPanel)m;
		
		m = vm.modules.get("Num Pad");
		NumPad np= (NumPad) m;
		
		m=vm.modules.get("Coin Acceptor");
		CoinReader cr =  (CoinReader) m;
		
		m=vm.modules.get("Change Case");
		ChangeCase cc= (ChangeCase)m;
		
		m=vm.modules.get("Product Case");
		ProductCase pc = (ProductCase)m;

//-----------RecipeManager

		try {			//ta grafw ola mesa sto try
			
				RecipeManager rManager = new RecipeManager();
				rManager.loadRecipes();
				do {
						System.out.println("\nPlease Choose a Drink:");
						for (Recipe r: rManager.getRecipes() ) {
							System.out.println(r.getCode() + r.getName());
							
						//	r.print(); //print tis syntages
						}
				
		//-----------NumPad
						
						int code  = 0;
						int money = 0;
						
						try {
							code = np.readCode(3);  //o arithmos toy length
							
						}catch (LockedModuleException e) {
							e.printStackTrace();
						}catch (WrongDigitException e) {
							e.printStackTrace();
						}
						
						Recipe recipe = rManager.getRecipe(code);
						Boolean canBeExecuted = rManager.canBeExecuted(recipe, vm);
				
		//-----------CoinReader
						if(canBeExecuted) {
								try {
									money = cr.receiveMoney(recipe.getCost());
									dp.displayMsg("You entered : "+money+" �");
							    
								} catch (LockedModuleException e) {
									e.printStackTrace();
								}
						
		//-----------ChangeCase
						 //an den exei resta mhn to kseklidwnw 
		
						
								int change = 0;
				 
								change= money-recipe.getCost();
								cc.setChange(change);
		
		//-----------ProductCase
						
		
								pc.prepareProduct(recipe.getType(), recipe.getName(), recipe.getCost());
						
		//************************EXECUTING	
						
								rManager.executeRecipe(recipe, vm, dp);
								
								dp.displayMsg(pc.getNameProduct());
						}else dp.displayMsg("OUT OF CONSUMABLES!!");
				}while(true);
		
		}	catch(Exception e) {
			e.printStackTrace();
		}
	
	}
	
	public static void runSwingVm(SwingVM svm ) {
		
		RecipeManager rManager;
		try {
			
			rManager = new RecipeManager();
			rManager.loadRecipes();
			
	
			
			SwingNumPad nump 				= (SwingNumPad) SwingVM.getInstance().getDevice("NUMPAD");
			SwingCoinAcceptor coinAcceptor  = (SwingCoinAcceptor) SwingVM.getInstance().getDevice("COINACCEPTOR");
			SwingChangeCase changeCase 		= (SwingChangeCase) SwingVM.getInstance().getDevice("CHANGECASE");
			SwingProductCase productCase 	= (SwingProductCase) SwingVM.getInstance().getDevice("PRODUCTCASE");
			SwingDisplayPanel displayPanel  = (SwingDisplayPanel) SwingVM.getInstance().getDevice("DISPLAYPANEL");
			SwingVM.sleep(3);
	
			displayPanel.displayMenu(rManager.getRecipes());
	
			do {
				nump.reset();
				coinAcceptor.reset();
				changeCase.reset();
				
				nump.unLock();
				coinAcceptor.unLock();
				int code = nump.readDigit("");
				System.out.println("digit pressed = " + code);
				nump.lock();
				coinAcceptor.lock();
	
				Recipe recipe = rManager.getRecipe(code);
				Boolean canBeExecuted = rManager.canBeExecuted(recipe, svm);
	
				changeCase.unLock();
				
				if(canBeExecuted) {
						if (coinAcceptor.inputMoney < recipe.getCost()) {
							displayPanel.displayMsg("Not enough money entered for your order. Please try again.");
							SwingVM.sleep(3);
							changeCase.giveChange(coinAcceptor.inputMoney);
						} else {
							changeCase.giveChange(coinAcceptor.inputMoney - recipe.getCost());
			
							ProductCase pc = new ProductCase(productCase);
							pc.prepareProduct(recipe.getType(), recipe.getName(), recipe.getCost());
			
							for (int i = 0; i < recipe.steps.size(); i++) {
								if (recipe.steps.get(i).getClass().equals(OperateStep.class)) {
									OperateStep operateStep = (OperateStep) recipe.steps.get(i);
									if (operateStep.getProcessor().equals("BOILER")) {
										GraphicProcessor boiler = (GraphicProcessor) SwingVM.getInstance().getDevice("BOILER");
										boiler.open();
										boiler.operateStart();
										boiler.operateStop();
										boiler.close();
									} else if (operateStep.getProcessor().equals("MIXER")) {
										GraphicProcessor mixer = (GraphicProcessor) SwingVM.getInstance().getDevice("MIXER");
										mixer.open();
										mixer.operateStart();
										mixer.operateStop();
										mixer.close();
									} else if (operateStep.getProcessor().equals("BUFFER")) {
										GraphicProcessor buffer = (GraphicProcessor) SwingVM.getInstance().getDevice("BUFFER");
										buffer.open();
										buffer.operateStart();
										buffer.operateStop();
										buffer.close();
									} else if (operateStep.getProcessor().equals("COOLER")) {
										GraphicProcessor cooler = (GraphicProcessor) SwingVM.getInstance().getDevice("COOLER");
										cooler.open();
										cooler.operateStart();
										cooler.operateStop();
										cooler.close();
									}
								} else if (recipe.steps.get(i).getClass().equals(TransferStep.class)) {
									TransferStep transferStep = (TransferStep) recipe.steps.get(i);
			
									GraphicDosingContainer conFrom = null;
			
									if (transferStep.getFrom().equals("POWDERS")) {
										if (transferStep.getWhat().equals("SUGAR"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("SUGAR");
										else if (transferStep.getWhat().equals("CINNAMON"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("CINNAMON");
										else if (transferStep.getWhat().equals("CHOCOLATE"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("CHOCOLATE");
										else if (transferStep.getWhat().equals("COFFEE"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("COFFEE");
									} else if (transferStep.getFrom().equals("LIQUIDS")) {
										if (transferStep.getWhat().equals("MILK"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("MILK");
										else if (transferStep.getWhat().equals("WATER"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("WATER");
									} else if (transferStep.getFrom().equals("CUPS")) {
										if (transferStep.getWhat().equals("BIGCUP"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("BIGCUP");
										else if (transferStep.getWhat().equals("SMALLCUP"))
											conFrom = (GraphicDosingContainer) SwingVM.getInstance().getDevice("SMALLCUP");
									}
			
									if (conFrom != null) {
										conFrom.open();
										for(int k = 0; k < transferStep.getQuantity()/conFrom.doseSize();k++)
											conFrom.releaseDose(null);
										SwingVM.sleep(2);
										conFrom.close();
									}
									
								}
							}
							
							try {
								productCase.setFinalProduct(pc.getProduct());
							} catch (RecipeStepException e) {
								e.printStackTrace();
							}
							productCase.unLock();
						}
				}else {
					displayPanel.displayMsg("OUT OF CONSUMABLES!");
					SwingVM.sleep(3);
					changeCase.giveChange(coinAcceptor.inputMoney);
				}
			} while (true);
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}
		
	}
		
	
}