package vendingMachine;

import java.util.ArrayList;
import java.util.HashMap;

import consumambles.Ingredient;
import hw.consoles.HardwareMachineConsole;
import tuc.ece.cs201.vm.hw.HardwareMachine;
import tuc.ece.cs201.vm.hw.device.Device;
import userModules.Module;

public class VendingMachine  {

	//ArrayList<Module> moduleList;
	public HashMap<String, Module> modules;   //keys values
	private static VendingMachine instance;
	
	private VendingMachine() {
		this.modules = new HashMap<>();
	}
	
	private VendingMachine(HardwareMachine machine) {
		this.modules = new HashMap<>();
		this.probeHardware(machine);

	}

	public void initMachine(HardwareMachine machine) {  
		if (!modules.isEmpty())
			throw new AssertionError("Software Machine has already been initialized based on a HardwareMachine");
		probeHardware(machine);
	}
	
	public static VendingMachine getInstance() {
		if (instance!=null)
			return instance;
		else
			instance = new VendingMachine();  
		return instance;
	}
	
	public void addModule(Module m) {
		this.modules.put(m.getName(), m);
		System.out.println("Module "+m.getName()+ " added.");
	}

	private void probeHardware(HardwareMachine machine) {
		for (Device dev : machine.listDevices()) {
			this.addModule(ModuleFactory.createModule(dev));
		}
		
	}

}
