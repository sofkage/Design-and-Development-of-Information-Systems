package vendingMachine;

import consumambles.Consumable;
import exceptions.NotExistantConsumable;

public interface Consumer {
	
	public void load(Consumable con) throws NotExistantConsumable;
	public boolean accepts(Consumable consumable) throws NotExistantConsumable;

}
