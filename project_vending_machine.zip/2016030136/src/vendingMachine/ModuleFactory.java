package vendingMachine;

import containers.Container;
import containers.DosingContainer;
import containers.FlowContainer;
import containers.MaterialContainer;
import dispensers.ConsumableDispenser;
import processors.IngredientProcessor;
import tuc.ece.cs201.vm.hw.device.ChangeCaseDevice;
import tuc.ece.cs201.vm.hw.device.CoinAcceptorDevice;
import tuc.ece.cs201.vm.hw.device.Device;
import tuc.ece.cs201.vm.hw.device.DispenserDevice;
import tuc.ece.cs201.vm.hw.device.DisplayDevice;
import tuc.ece.cs201.vm.hw.device.DosingContainerDevice;
import tuc.ece.cs201.vm.hw.device.FlowContainerDevice;
import tuc.ece.cs201.vm.hw.device.MaterialContainerDevice;
import tuc.ece.cs201.vm.hw.device.NumPadDevice;
import tuc.ece.cs201.vm.hw.device.ProcessorDevice;
import tuc.ece.cs201.vm.hw.device.ProductCaseDevice;
import userModules.ChangeCase;
import userModules.CoinReader;
import userModules.DisplayPanel;
import userModules.Module;
import userModules.NumPad;
import userModules.ProductCase;

public class ModuleFactory {   

		public static Module createModule(Device device) {
			
			Module m=null;
			
			switch (device.getType()) {
			case ChangeCase:
				m = new ChangeCase((ChangeCaseDevice)device);
				System.out.println("Change Case Module Created");

				break;
				
			case CoinReader:
				m = new CoinReader((CoinAcceptorDevice) device);
				System.out.println("Coin Acceptor Module Created");
				break;
				
			case DosingContainer:
				m = new DosingContainer((DosingContainerDevice)device);
				System.out.println("Dosing Container Module Created");
				break;
				
			case Display:
				m = new DisplayPanel((DisplayDevice)device);
				System.out.println("Display Module Created");
				break;
				
			case DosingDispenser:
				m = new ConsumableDispenser<DosingContainerDevice>((DispenserDevice)device);
				System.out.println("Dosing Container Module Created");
				for (Device cont: ((DispenserDevice)device).listConnectedDevices()) {
					((ConsumableDispenser)m).addContainer((Container)createModule(cont));
					System.out.println("Container Added to Dosing Dispenser");
				}
				break;
				
			case FlowContainer:
				m = new FlowContainer((FlowContainerDevice)device);
				System.out.println("Flow Container Module Created");
				break;
				
			case FlowDispenser:
				m = new ConsumableDispenser((DispenserDevice)device);
				System.out.println("Dosing Container Module Created");
				for (Device cont: ((DispenserDevice)device).listConnectedDevices()) {
					((ConsumableDispenser)m).addContainer((Container)createModule(cont));
					System.out.println("Container Added to Flow Dispenser");
				}
				break;
				
			case MaterialContainer:
				m = new MaterialContainer((MaterialContainerDevice)device);
				System.out.println("Material Container Module Created");
				break;
				
			case MaterialDispenser:		
				m = new ConsumableDispenser<MaterialContainerDevice>((DispenserDevice)device);
				System.out.println("Material Dispenser Module Created");
				for (Device cont: ((DispenserDevice)device).listConnectedDevices()) {
					((ConsumableDispenser)m).addContainer((Container)createModule(cont));
					System.out.println("Container Added to Material Dispenser");
				}		
				break;
				
			case NumPad:
				m = new NumPad((NumPadDevice)device);
				System.out.println("NumPad Module Created");
				break;
				
			case Processor:
				m = new IngredientProcessor((ProcessorDevice)device);
				System.out.println(device.getName()+ " Processor Module Created");

				break;
			case ProductCase:
				m = new ProductCase((ProductCaseDevice)device);
				System.out.println("Product Case Module Created");
				break;
			default:
				break;
			}
			
			return m;
		}
		
	

}
