package vendingMachine;

import exceptions.PluggedException;

public interface Pluggable {
	
	public void plug(Consumer consumer) throws PluggedException ;
	public void unPlug(Consumer consumer) throws PluggedException;
	public void unPlugAll();
	public boolean isPlugged();
	
	

}
