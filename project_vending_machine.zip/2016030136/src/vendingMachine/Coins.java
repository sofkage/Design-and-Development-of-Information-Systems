package vendingMachine;

public class Coins {
	public static final int cents_1 = 1;
	public static final int cents_2 = 2;
	public static final int cents_5 = 5;
	public static final int cents_10 = 10;
	public static final int cents_20 = 20;
	public static final int cents_50 = 50;
	public static final int cents_100 = 100;
	public static final int cents_200 = 200;
}
