package vendingMachine;

import exceptions.NotExistantConsumable;
import exceptions.PluggedException;

public interface Provider extends Pluggable{

	public void provide(Consumer confRef, int quantity) throws NotExistantConsumable, PluggedException;
	public void provide(Consumer confRef) throws NotExistantConsumable;
	
}
